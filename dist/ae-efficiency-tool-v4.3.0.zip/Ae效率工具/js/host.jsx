﻿function AeEff_ping() {
    return hx_0x222a(0x1dc);
}
function AeEff_parseArg(_0x131598) {
    if (typeof _0x131598 === 'string') {
        var _0x46a95b = _0x131598[hx_0x222a(0x1dd)](/^\s+|\s+$/g, '');
        if (/^[[{]/[hx_0x222a(0x1de)](_0x46a95b))
            try {
                return JSON[hx_0x222a(0x1df)](_0x46a95b);
            } catch (_0x134d01) {
                return _0x131598;
            }
        return _0x131598;
    }
    return _0x131598;
}
function AeEff_getKey() {
    try {
        return app['settings'][hx_0x222a(0x1e0)](hx_0x222a(0x1e1), hx_0x222a(0x1e2)) || '';
    } catch (_0x364a5b) {
        return '';
    }
}
function AeEff_setKey(_0x1ec30c) {
    try {
        return app[hx_0x222a(0x1e3)]['saveSetting'](hx_0x222a(0x1e1), hx_0x222a(0x1e2), _0x1ec30c), 'ok';
    } catch (_0x1ead57) {
        return 'err:' + _0x1ead57[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getModel() {
    try {
        return app['settings']['getSetting'](hx_0x222a(0x1e1), hx_0x222a(0x1e5)) || hx_0x222a(0x1e6);
    } catch (_0x1004d2) {
        return hx_0x222a(0x1e6);
    }
}
function AeEff_setModel(_0x31bcce) {
    try {
        return app[hx_0x222a(0x1e3)]['saveSetting'](hx_0x222a(0x1e1), 'ElevenLabsModel', _0x31bcce), 'ok';
    } catch (_0xbada35) {
        return hx_0x222a(0x1e7) + _0xbada35[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getSettings() {
    try {
        return app['settings'][hx_0x222a(0x1e0)](hx_0x222a(0x1e1), hx_0x222a(0x1e8)) || '';
    } catch (_0x3f1b2c) {
        return '';
    }
}
function AeEff_setSettings(_0x489caf) {
    try {
        return app[hx_0x222a(0x1e3)]['saveSetting'](hx_0x222a(0x1e1), hx_0x222a(0x1e8), _0x489caf), 'ok';
    } catch (_0x41d601) {
        return hx_0x222a(0x1e7) + _0x41d601['toString']();
    }
}
function AeEff_getVoicesCache() {
    try {
        return app[hx_0x222a(0x1e3)][hx_0x222a(0x1e0)](hx_0x222a(0x1e1), 'ElevenLabsVoices') || '';
    } catch (_0x3c3fdb) {
        return '';
    }
}
function AeEff_setVoicesCache(_0x28b3b8) {
    try {
        return app[hx_0x222a(0x1e3)]['saveSetting'](hx_0x222a(0x1e1), hx_0x222a(0x1e9), _0x28b3b8), 'ok';
    } catch (_0x265997) {
        return 'err:' + _0x265997[hx_0x222a(0x1e4)]();
    }
}
function AeEff_readSelectedLayerText() {
    try {
        var _0x137720 = app['project'][hx_0x222a(0x1ea)];
        if (!_0x137720 || !(_0x137720 instanceof CompItem))
            return hx_0x222a(0x1eb);
        if (_0x137720[hx_0x222a(0x1ec)]['length'] === 0x0)
            return hx_0x222a(0x1ed);
        var _0x2fc02f = _0x137720['selectedLayers'][0x0];
        if (!_0x2fc02f[hx_0x222a(0x1ee)](hx_0x222a(0x1ef)))
            return hx_0x222a(0x1f0);
        var _0x24e781 = _0x2fc02f['property'](hx_0x222a(0x1ef))['value']['text'];
        return _0x24e781 ? _0x24e781 : '';
    } catch (_0x1dba5a) {
        return hx_0x222a(0x1f1) + _0x1dba5a[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getSelectedTextLayers() {
    try {
        var _0x3b9b84 = app['project'][hx_0x222a(0x1ea)];
        if (!_0x3b9b84 || !(_0x3b9b84 instanceof CompItem))
            return hx_0x222a(0x1eb);
        if (_0x3b9b84[hx_0x222a(0x1ec)][hx_0x222a(0x1f2)] === 0x0)
            return 'ERR:no_layer';
        var _0x528b5d = [];
        for (var _0x344323 = 0x0; _0x344323 < _0x3b9b84[hx_0x222a(0x1ec)][hx_0x222a(0x1f2)]; _0x344323++) {
            var _0x4e654b = _0x3b9b84[hx_0x222a(0x1ec)][_0x344323];
            if (!_0x4e654b['property'](hx_0x222a(0x1ef)))
                continue;
            var _0x24bb91 = _0x4e654b['property'](hx_0x222a(0x1ef))[hx_0x222a(0x1f3)]['text'];
            _0x528b5d[hx_0x222a(0x1f4)]({
                'index': _0x4e654b['index'],
                'text': _0x24bb91 ? _0x24bb91 : '',
                'inPoint': _0x4e654b['inPoint']
            });
        }
        if (_0x528b5d[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x1f5);
        return JSON['stringify'](_0x528b5d);
    } catch (_0x101498) {
        return hx_0x222a(0x1f1) + _0x101498['toString']();
    }
}
function AeEff_getProjectDir() {
    try {
        if (app[hx_0x222a(0x1f6)] && app[hx_0x222a(0x1f6)]['file'])
            return app['project'][hx_0x222a(0x1f7)][hx_0x222a(0x1f8)][hx_0x222a(0x1f9)];
        return '';
    } catch (_0x53dd0f) {
        return '';
    }
}
function AeEff_getAudioDir() {
    try {
        var _0x3dcfc6 = AeEff_getProjectDir();
        if (_0x3dcfc6 && _0x3dcfc6[hx_0x222a(0x1f2)] > 0x0) {
            var _0x22cd25 = new Folder(_0x3dcfc6 + hx_0x222a(0x1fa))[hx_0x222a(0x1fb)], _0x636709 = new Folder(_0x22cd25);
            return !_0x636709['exists'] && _0x636709['create'](), _0x22cd25;
        }
    } catch (_0x3f5ed2) {
    }
    return '';
}
function hx_0x38a8() {
    var _0x411db = [
        'pong',
        'replace',
        'test',
        'parse',
        'getSetting',
        'AeEfficiencyTool',
        'ElevenLabsKey',
        'settings',
        'toString',
        'ElevenLabsModel',
        'eleven_multilingual_v2',
        'err:',
        'ElevenLabsSettings',
        'ElevenLabsVoices',
        'activeItem',
        'ERR:no_comp',
        'selectedLayers',
        'ERR:no_layer',
        'property',
        'Source\x20Text',
        'ERR:not_text',
        'ERR:',
        'length',
        'value',
        'push',
        'ERR:no_text_layer',
        'project',
        'file',
        'parent',
        'fsName',
        '/Audios',
        'fullName',
        'numItems',
        'name',
        'items',
        'addFolder',
        'parentFolder',
        'AeEff\x20Add\x20Audio',
        'endUndoGroup',
        'numLayers',
        'layer',
        'AeEff_Audio',
        'importAs',
        'FOOTAGE',
        'layers',
        'moveBefore',
        'moveToBeginning',
        'inPoint',
        'duration',
        'startTime',
        'beginUndoGroup',
        'AeEff\x20Add\x20Subtitles',
        'ERR:empty',
        'AeEff_Sub_',
        'start',
        'outPoint',
        'height',
        'justification',
        'CENTER_JUSTIFY',
        'setValue',
        'saveSetting',
        'ArrangeParams',
        'rows',
        'randomize',
        'createdLayers',
        'remove',
        'source',
        'width',
        'AeEff\x20棋子排列',
        'floor',
        'random',
        'Scale',
        'Rotation',
        'Opacity',
        'Position',
        'originalData',
        'stringify',
        'ERR:no_snapshot',
        'src',
        'selected',
        'pos',
        'ERR:need_2',
        'replaceSource',
        'shape',
        'growthTime',
        'order',
        'sqrt',
        'abs',
        'sort',
        'time',
        'AeEff\x20生长动画',
        'numKeys',
        'setValueAtTime',
        'setTemporalEaseAtKey',
        'selection',
        'vacation',
        'baseKw',
        'itembase',
        'toLowerCase',
        'min',
        'indexOf',
        '01_Project',
        '02_Sequence',
        '03_Part',
        '04_Picture',
        '05_Movie',
        '06_Music',
        '07_Audios',
        'haveSetting',
        'FolderList',
        'join',
        'ERR:no_project',
        '|||',
        'number',
        'ERR:no_times',
        'frameDuration',
        'Marker',
        'addProperty',
        'var\x20outComp\x20=\x20comp(\x22',
        'var\x20base\x20=\x20',
        'var\x20step\x20=\x20',
        'var\x20sep\x20=\x20',
        '\x20\x20var\x20s\x20=\x20String(Math.round(v));',
        '\x20\x20if\x20(s.charAt(0)\x20===\x20\x22-\x22)\x20{\x20neg\x20=\x20\x22-\x22;\x20s\x20=\x20s.substring(1);\x20}',
        '\x20\x20var\x20out\x20=\x20\x22\x22;\x20var\x20cnt\x20=\x200;',
        '\x20\x20}',
        '\x20\x20return\x20neg\x20+\x20out;',
        'var\x20n\x20=\x20mk.numKeys,\x20t\x20=\x20time;',
        'var\x20idx\x20=\x200;',
        'if\x20(idx\x20===\x200)\x20{',
        '\x20\x20sep\x20?\x20fmtNum(base)\x20:\x20String(base);',
        '\x20\x20var\x20prevVal\x20=\x20base\x20+\x20(idx\x20-\x201)\x20*\x20step;',
        '\x20\x20var\x20tA\x20=\x20mk.key(idx).time;',
        '\x20\x20var\x20val\x20=\x20curVal;',
        '\x20\x20\x20\x20var\x20fRaw\x20=\x20(t\x20-\x20tA)\x20/\x20dur;',
        '\x20\x20\x20\x20if\x20(fRaw\x20<\x200)\x20fRaw\x20=\x200;',
        '\x20\x20\x20\x20if\x20(fRaw\x20>\x201)\x20fRaw\x20=\x201;',
        '\x20\x20\x20\x20var\x20f\x20=\x201\x20-\x20Math.pow(1\x20-\x20fRaw,\x203);',
        '\x20\x20\x20\x20val\x20=\x20prevVal\x20+\x20(curVal\x20-\x20prevVal)\x20*\x20f;',
        '\x20\x20sep\x20?\x20fmtNum(val)\x20:\x20String(Math.round(val));',
        'var\x20mk\x20=\x20thisLayer.marker;',
        'var\x20scaleAmt\x20=\x20',
        'var\x20popDur\x20=\x20',
        'for\x20(var\x20i\x20=\x201;\x20i\x20<=\x20n;\x20i++)\x20{\x20if\x20(t\x20>=\x20mk.key(i).time)\x20idx++;\x20}',
        'var\x20f\x20=\x201;',
        '\x20\x20var\x20dt\x20=\x20t\x20-\x20tA;',
        '\x20\x20if\x20(dt\x20>=\x200\x20&&\x20dt\x20<\x20popDur)\x20{',
        '\x20\x20\x20\x20var\x20env\x20=\x20(Math.sin(2\x20*\x20Math.PI\x20*\x20p)\x20*\x20(1\x20-\x20p))\x20/\x200.75;',
        '\x20\x20\x20\x20f\x20=\x201\x20+\x20(scaleAmt\x20/\x20100)\x20*\x20env;',
        'var\x20out\x20=\x20[];',
        'for\x20(var\x20k\x20=\x200;\x20k\x20<\x20base.length;\x20k++)\x20{\x20out.push(base[k]\x20*\x20f);\x20}',
        'out;',
        '选择文字图层',
        'orientation',
        'column',
        'alignChildren',
        'fill',
        'statictext',
        'add',
        'item',
        'row',
        'alignment',
        'top',
        'onClick',
        'index',
        'close',
        'show',
        'sep',
        'scaleAmt',
        'max',
        'ERR:need_one_precomp',
        'ERR:not_precomp',
        'ERR:no_text',
        'ERR:no_target',
        'text',
        'boxText',
        'sourceRectAtTime',
        'LEFT',
        'CENTER',
        'anchorPoint',
        'position',
        'expression',
        'ERR:apply_fail:',
        '倒计时',
        '//\x20获取当前合成的总时间（秒）\x0avar\x20totalSeconds\x20=\x20thisComp.duration;\x0a\x0a//\x20获取当前播放到的时间（秒）\x0avar\x20currentTime\x20=\x20time;\x0a\x0a//\x20计算倒计时：总时间\x20-\x20当前时间\x0avar\x20timeLeft\x20=\x20Math.max(0,\x20totalSeconds\x20-\x20currentTime);\x0a\x0a//\x20换算成分钟和秒数\x0avar\x20minutes\x20=\x20Math.floor(timeLeft\x20/\x2060);\x0avar\x20seconds\x20=\x20Math.floor(timeLeft\x20%\x2060);\x0a\x0a//\x20格式化输出，确保始终显示两位数\x20(如\x2001:05)\x0avar\x20minStr\x20=\x20(minutes\x20<\x2010)\x20?\x20\x220\x22\x20+\x20minutes\x20:\x20minutes;\x0avar\x20secStr\x20=\x20(seconds\x20<\x2010)\x20?\x20\x220\x22\x20+\x20seconds\x20:\x20seconds;\x0a\x0aminStr\x20+\x20\x22:\x22\x20+\x20secStr;',
        'ExprLibDeleted',
        'ExprLib',
        'expr',
        'selectedProperties',
        'ERR:no_prop',
        '应用表达式',
        'windows',
        'diskCache',
        'temp',
        'mediaCache',
        'userData',
        '~/Library/Caches/Adobe/Common/Media\x20Cache\x20Files',
        '~/Library/Caches/Adobe/Common',
        'peaks',
        '/Peak\x20Files',
        'Disk\x20Cache',
        'Folder',
        'Media\x20&\x20Disk\x20Cache',
        'Database\x20Folder',
        'exists',
        'getFiles',
        'Files',
        'ERR:no_media_cache',
        'comp',
        'footage',
        'all',
        'ERR:no_selection',
        'ERR:no_find_text',
        'split',
        'ERR:invalid_fps',
        '修改帧速率',
        'conformFrameRate',
        '修改循环次数',
        'mainSource',
        'loop',
        'AeEffGroup:',
        'AeEffMember:',
        'substring',
        'comment',
        'trim',
        'nullLayer',
        'string',
        '创建图层组',
        'addNull',
        'getTime',
        'ERR:no_id',
        'ERR:group_not_found',
        'shy',
        'hideShyLayers',
        'color',
        'solo',
        'collapsed',
        '折叠/展开图层组',
        '独奏图层组',
        '解组图层组',
        'concat',
        '调整图层组顺序',
        'bottom',
        'moveToEnd',
        'CLOSED',
        'UNSAVED'
    ];
    hx_0x38a8 = function () {
        return _0x411db;
    };
    return hx_0x38a8();
}
function AeEff_moveToAudioFolder(_0x291f85) {
    try {
        var _0x3fb679 = '07_Audios', _0x17f9f0 = null;
        for (var _0x2f1484 = 0x1; _0x2f1484 <= app['project'][hx_0x222a(0x1fc)]; _0x2f1484++) {
            var _0xdaf17 = app[hx_0x222a(0x1f6)]['item'](_0x2f1484);
            if (_0xdaf17 instanceof FolderItem && _0xdaf17[hx_0x222a(0x1fd)] === _0x3fb679) {
                _0x17f9f0 = _0xdaf17;
                break;
            }
        }
        !_0x17f9f0 && (_0x17f9f0 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1fe)][hx_0x222a(0x1ff)](_0x3fb679)), _0x291f85[hx_0x222a(0x200)] = _0x17f9f0;
    } catch (_0x5909c1) {
    }
}
function AeEff_addAudioLayer(_0x7666a7, _0x10e217, _0x3864e2, _0x25c204) {
    try {
        app['beginUndoGroup'](hx_0x222a(0x201));
        var _0x5f6458 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x5f6458 || !(_0x5f6458 instanceof CompItem))
            return app[hx_0x222a(0x202)](), 'ERR:no_comp';
        var _0x2076e7;
        if (_0x25c204 !== undefined && _0x25c204 !== null && _0x25c204 !== '')
            _0x2076e7 = _0x5f6458['layer'](parseInt(_0x25c204));
        else
            _0x5f6458[hx_0x222a(0x1ec)]['length'] > 0x0 && (_0x2076e7 = _0x5f6458[hx_0x222a(0x1ec)][0x0]);
        if (!_0x2076e7)
            return app[hx_0x222a(0x202)](), hx_0x222a(0x1ed);
        if (_0x10e217 === hx_0x222a(0x1dd))
            for (var _0x5e018e = _0x5f6458[hx_0x222a(0x203)]; _0x5e018e >= 0x1; _0x5e018e--) {
                try {
                    var _0x440ab8 = _0x5f6458[hx_0x222a(0x204)](_0x5e018e);
                    _0x440ab8 && _0x440ab8[hx_0x222a(0x1fd)] === hx_0x222a(0x205) && _0x440ab8['remove']();
                } catch (_0x2ec3f6) {
                }
            }
        var _0xd3c24c = new ImportOptions();
        _0xd3c24c[hx_0x222a(0x1f7)] = new File(_0x7666a7), _0xd3c24c[hx_0x222a(0x206)] = ImportAsType[hx_0x222a(0x207)];
        var _0x21f3bf = app['project']['importFile'](_0xd3c24c);
        if (!_0x21f3bf)
            return app['endUndoGroup'](), 'ERR:import_failed';
        try {
            AeEff_moveToAudioFolder(_0x21f3bf);
        } catch (_0x512563) {
        }
        var _0x59944f = _0x5f6458[hx_0x222a(0x208)]['add'](_0x21f3bf);
        _0x59944f[hx_0x222a(0x1fd)] = 'AeEff_Audio';
        try {
            _0x59944f[hx_0x222a(0x209)](_0x2076e7);
        } catch (_0x473ee1) {
            try {
                _0x59944f[hx_0x222a(0x20a)]();
            } catch (_0xb22ac5) {
            }
        }
        var _0x438e08;
        try {
            _0x438e08 = _0x3864e2 !== undefined && _0x3864e2 !== null && _0x3864e2 !== '' ? parseFloat(_0x3864e2) : _0x2076e7['inPoint'];
            if (isNaN(_0x438e08))
                _0x438e08 = _0x2076e7[hx_0x222a(0x20b)];
        } catch (_0x107ae3) {
            _0x438e08 = 0x0;
        }
        var _0x50fb7e = _0x21f3bf[hx_0x222a(0x20c)] || 0x1;
        return _0x59944f[hx_0x222a(0x20d)] = _0x438e08, _0x59944f[hx_0x222a(0x20b)] = _0x438e08, _0x59944f['outPoint'] = _0x438e08 + _0x50fb7e, app[hx_0x222a(0x202)](), 'ok:' + _0x59944f['index'] + ':' + _0x50fb7e;
    } catch (_0x26622b) {
        try {
            app[hx_0x222a(0x202)]();
        } catch (_0x5c72cb) {
        }
        return 'ERR:' + _0x26622b['toString']();
    }
}
function AeEff_addSubtitleLayers(_0x18ad14) {
    try {
        app[hx_0x222a(0x20e)](hx_0x222a(0x20f));
        var _0x5b831e = app['project']['activeItem'];
        if (!_0x5b831e || !(_0x5b831e instanceof CompItem))
            return app[hx_0x222a(0x202)](), hx_0x222a(0x1eb);
        var _0x225061 = AeEff_parseArg(_0x18ad14);
        if (!_0x225061 || _0x225061[hx_0x222a(0x1f2)] === 0x0)
            return app['endUndoGroup'](), hx_0x222a(0x210);
        for (var _0x208ab5 = 0x0; _0x208ab5 < _0x225061[hx_0x222a(0x1f2)]; _0x208ab5++) {
            var _0x4f0c54 = _0x225061[_0x208ab5], _0xb5179d = _0x5b831e['layers']['addText'](_0x4f0c54['text']);
            _0xb5179d[hx_0x222a(0x1fd)] = hx_0x222a(0x211) + (_0x208ab5 + 0x1), _0xb5179d[hx_0x222a(0x20d)] = parseFloat(_0x4f0c54[hx_0x222a(0x212)]), _0xb5179d[hx_0x222a(0x20b)] = parseFloat(_0x4f0c54['start']), _0xb5179d[hx_0x222a(0x213)] = parseFloat(_0x4f0c54['end']);
            try {
                var _0x1698d2 = _0xb5179d[hx_0x222a(0x1ee)]('Source\x20Text')['value'];
                _0x1698d2['fontSize'] = Math['round'](_0x5b831e[hx_0x222a(0x214)] / 0x12), _0x1698d2[hx_0x222a(0x215)] = ParagraphJustification[hx_0x222a(0x216)], _0xb5179d['property'](hx_0x222a(0x1ef))[hx_0x222a(0x217)](_0x1698d2);
            } catch (_0x13262b) {
            }
            _0xb5179d['property']('Position')['setValue']([
                _0x5b831e['width'] / 0x2,
                _0x5b831e['height'] - Math['round'](_0x5b831e[hx_0x222a(0x214)] / 0x8)
            ]);
        }
        return app['endUndoGroup'](), 'ok:' + _0x225061['length'];
    } catch (_0x492e6d) {
        try {
            app[hx_0x222a(0x202)]();
        } catch (_0x57f9aa) {
        }
        return hx_0x222a(0x1f1) + _0x492e6d[hx_0x222a(0x1e4)]();
    }
}
var _arrangeSnapshot = null, _replaceComps = [], _replaceSkins = [], _replaceBases = [];
function AeEff_getArrangeParams() {
    try {
        return app[hx_0x222a(0x1e3)]['getSetting'](hx_0x222a(0x1e1), 'ArrangeParams') || '';
    } catch (_0x532dce) {
        return '';
    }
}
function AeEff_setArrangeParams(_0x5916a9) {
    try {
        return app[hx_0x222a(0x1e3)][hx_0x222a(0x218)]('AeEfficiencyTool', hx_0x222a(0x219), _0x5916a9), 'ok';
    } catch (_0x8401d6) {
        return 'err:' + _0x8401d6[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getSelectedLayerNames() {
    try {
        var _0x48d79d = app[hx_0x222a(0x1f6)]['activeItem'];
        if (!_0x48d79d || !(_0x48d79d instanceof CompItem))
            return 'ERR:no_comp';
        var _0x5a406a = [];
        for (var _0x1b26c7 = 0x0; _0x1b26c7 < _0x48d79d[hx_0x222a(0x1ec)]['length']; _0x1b26c7++) {
            _0x5a406a[hx_0x222a(0x1f4)](_0x48d79d['selectedLayers'][_0x1b26c7]['name']);
        }
        return JSON['stringify']({
            'count': _0x5a406a[hx_0x222a(0x1f2)],
            'names': _0x5a406a
        });
    } catch (_0x50ea5e) {
        return hx_0x222a(0x1f1) + _0x50ea5e['toString']();
    }
}
function AeEff_arrangePieces(_0x27dcd4) {
    try {
        var _0x326610 = AeEff_parseArg(_0x27dcd4), _0x15fba7 = parseInt(_0x326610['cols'], 0xa), _0x15889b = parseInt(_0x326610[hx_0x222a(0x21a)], 0xa), _0x289e59 = parseFloat(_0x326610['spacing']), _0x114bd0 = _0x326610[hx_0x222a(0x21b)] === !![] || _0x326610[hx_0x222a(0x21b)] === '1' || _0x326610[hx_0x222a(0x21b)] === 0x1;
        if (!(_0x15fba7 >= 0x1) || !(_0x15889b >= 0x1))
            return 'ERR:bad_grid';
        var _0x2dd232 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x2dd232 || !(_0x2dd232 instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x39e471 = [];
        for (var _0x48aaba = 0x0; _0x48aaba < _0x2dd232[hx_0x222a(0x1ec)][hx_0x222a(0x1f2)]; _0x48aaba++) {
            _0x39e471[hx_0x222a(0x1f4)](_0x2dd232['selectedLayers'][_0x48aaba]);
        }
        if (_0x39e471[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x1ed);
        if (_arrangeSnapshot && _arrangeSnapshot['createdLayers']) {
            for (var _0x523d1f = 0x0; _0x523d1f < _arrangeSnapshot[hx_0x222a(0x21c)][hx_0x222a(0x1f2)]; _0x523d1f++) {
                try {
                    _arrangeSnapshot['createdLayers'][_0x523d1f][hx_0x222a(0x21d)]();
                } catch (_0x1623e4) {
                }
            }
            _arrangeSnapshot = null;
        }
        var _0x59d9bf = _0x15fba7 * _0x15889b, _0x2fc076 = _0x39e471[0x0], _0x58cfb7, _0x1b061f;
        _0x2fc076[hx_0x222a(0x21e)] ? (_0x58cfb7 = _0x2fc076['source'][hx_0x222a(0x21f)] || 0x64, _0x1b061f = _0x2fc076[hx_0x222a(0x21e)][hx_0x222a(0x214)] || 0x64) : (_0x58cfb7 = _0x2dd232['width'] / _0x15fba7, _0x1b061f = _0x2dd232[hx_0x222a(0x214)] / _0x15889b);
        if (!_0x58cfb7 || !_0x1b061f || _0x58cfb7 <= 0x0 || _0x1b061f <= 0x0)
            return 'ERR:no_size';
        var _0x55f422 = _0x58cfb7 + _0x289e59, _0x3f8b86 = _0x1b061f + _0x289e59, _0x4b69d6 = _0x15fba7 * _0x58cfb7 + (_0x15fba7 - 0x1) * _0x289e59, _0x3cb916 = _0x15889b * _0x1b061f + (_0x15889b - 0x1) * _0x289e59, _0x22e5c3 = (_0x2dd232['width'] - _0x4b69d6) / 0x2 + _0x58cfb7 / 0x2, _0x5de15b = (_0x2dd232['height'] - _0x3cb916) / 0x2 + _0x1b061f / 0x2, _0x169b07 = [];
        for (var _0x2c0609 = 0x0; _0x2c0609 < _0x39e471[hx_0x222a(0x1f2)]; _0x2c0609++) {
            _0x169b07['push'](_0x39e471[_0x2c0609]);
        }
        var _0x8cdfa0 = [], _0x1c76b2 = [];
        app['beginUndoGroup'](hx_0x222a(0x220));
        for (var _0x3e5e5e = 0x0; _0x3e5e5e < _0x15889b; _0x3e5e5e++) {
            _0x1c76b2[_0x3e5e5e] = [];
            for (var _0x1733f4 = 0x0; _0x1733f4 < _0x15fba7; _0x1733f4++) {
                var _0x24d84e;
                if (_0x114bd0) {
                    var _0x381c0f = {}, _0x54164f = {};
                    for (var _0x465cf4 = 0x0; _0x465cf4 < _0x1733f4; _0x465cf4++) {
                        _0x381c0f[_0x1c76b2[_0x3e5e5e][_0x465cf4]] = !![];
                    }
                    for (var _0x2cd9b0 = 0x0; _0x2cd9b0 < _0x3e5e5e; _0x2cd9b0++) {
                        _0x54164f[_0x1c76b2[_0x2cd9b0][_0x1733f4]] = !![];
                    }
                    var _0x3c7f1d = [];
                    for (var _0x1a63f6 = 0x0; _0x1a63f6 < _0x39e471[hx_0x222a(0x1f2)]; _0x1a63f6++) {
                        !_0x381c0f[_0x1a63f6] && !_0x54164f[_0x1a63f6] && _0x3c7f1d[hx_0x222a(0x1f4)](_0x1a63f6);
                    }
                    _0x3c7f1d['length'] > 0x0 ? _0x24d84e = _0x3c7f1d[Math[hx_0x222a(0x221)](Math[hx_0x222a(0x222)]() * _0x3c7f1d[hx_0x222a(0x1f2)])] : _0x24d84e = Math[hx_0x222a(0x221)](Math[hx_0x222a(0x222)]() * _0x39e471['length']);
                } else
                    _0x24d84e = (_0x3e5e5e * _0x15fba7 + _0x1733f4) % _0x39e471['length'];
                _0x1c76b2[_0x3e5e5e][_0x1733f4] = _0x24d84e;
                var _0x7bfe9 = _0x39e471[_0x24d84e], _0x31ae2e = _0x7bfe9['duplicate']();
                if (_0x31ae2e) {
                    var _0x2cd470 = _0x22e5c3 + _0x1733f4 * _0x55f422, _0x3a40ad = _0x5de15b + _0x3e5e5e * _0x3f8b86;
                    try {
                        _0x31ae2e[hx_0x222a(0x1ee)](hx_0x222a(0x223))[hx_0x222a(0x217)]([
                            0x64,
                            0x64
                        ]);
                    } catch (_0x564d56) {
                    }
                    try {
                        _0x31ae2e[hx_0x222a(0x1ee)](hx_0x222a(0x224))[hx_0x222a(0x217)](0x0);
                    } catch (_0x52e32b) {
                    }
                    try {
                        _0x31ae2e[hx_0x222a(0x1ee)](hx_0x222a(0x225))[hx_0x222a(0x217)](0x64);
                    } catch (_0x3565a2) {
                    }
                    try {
                        _0x31ae2e[hx_0x222a(0x1ee)](hx_0x222a(0x226))[hx_0x222a(0x217)]([
                            _0x2cd470,
                            _0x3a40ad
                        ]);
                    } catch (_0x307030) {
                    }
                    _0x8cdfa0['push'](_0x31ae2e);
                }
            }
        }
        app['endUndoGroup']();
        var _0xe0c624 = {
            'createdLayers': _0x8cdfa0,
            'originalData': []
        };
        for (var _0x232d97 = 0x0; _0x232d97 < _0x169b07[hx_0x222a(0x1f2)]; _0x232d97++) {
            var _0x205628 = null, _0x3343f2 = null;
            try {
                _0x205628 = _0x169b07[_0x232d97][hx_0x222a(0x21e)];
            } catch (_0x405c06) {
            }
            try {
                _0x3343f2 = _0x169b07[_0x232d97][hx_0x222a(0x1ee)](hx_0x222a(0x226))[hx_0x222a(0x1f3)];
            } catch (_0x5b8aea) {
            }
            _0xe0c624[hx_0x222a(0x227)][hx_0x222a(0x1f4)]({
                'src': _0x205628,
                'pos': _0x3343f2
            });
        }
        _arrangeSnapshot = _0xe0c624;
        for (var _0x1ee3db = 0x0; _0x1ee3db < _0x169b07[hx_0x222a(0x1f2)]; _0x1ee3db++) {
            try {
                _0x169b07[_0x1ee3db]['remove']();
            } catch (_0x365cb9) {
            }
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'created': _0x8cdfa0['length'],
            'cols': _0x15fba7,
            'rows': _0x15889b,
            'types': _0x39e471['length']
        });
    } catch (_0x9fd8d6) {
        return 'ERR:' + _0x9fd8d6['toString']();
    }
}
function AeEff_undoArrange() {
    try {
        app[hx_0x222a(0x20e)]('AeEff\x20撤销排列');
        if (!_arrangeSnapshot || !_arrangeSnapshot[hx_0x222a(0x21c)])
            return hx_0x222a(0x229);
        var _0x12762f = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)], _0x1bfaab = 0x0;
        for (var _0x2bc4c3 = 0x0; _0x2bc4c3 < _arrangeSnapshot[hx_0x222a(0x21c)][hx_0x222a(0x1f2)]; _0x2bc4c3++) {
            try {
                _arrangeSnapshot[hx_0x222a(0x21c)][_0x2bc4c3]['remove'](), _0x1bfaab++;
            } catch (_0x477c0d) {
            }
        }
        if (_0x12762f && _0x12762f instanceof CompItem && _arrangeSnapshot[hx_0x222a(0x227)])
            for (var _0x2b5166 = 0x0; _0x2b5166 < _arrangeSnapshot[hx_0x222a(0x227)][hx_0x222a(0x1f2)]; _0x2b5166++) {
                var _0x161715 = _arrangeSnapshot['originalData'][_0x2b5166];
                if (_0x161715 && _0x161715['src'])
                    try {
                        var _0x29ee0d = _0x12762f[hx_0x222a(0x208)]['add'](_0x161715[hx_0x222a(0x22a)]);
                        if (_0x29ee0d) {
                            _0x29ee0d[hx_0x222a(0x22b)] = !![];
                            if (_0x161715['pos'])
                                try {
                                    _0x29ee0d['property']('Position')[hx_0x222a(0x217)](_0x161715[hx_0x222a(0x22c)]);
                                } catch (_0x51bf73) {
                                }
                            try {
                                _0x29ee0d['property']('Scale')[hx_0x222a(0x217)]([
                                    0x64,
                                    0x64
                                ]);
                            } catch (_0x546aa9) {
                            }
                            try {
                                _0x29ee0d[hx_0x222a(0x1ee)]('Rotation')[hx_0x222a(0x217)](0x0);
                            } catch (_0x16ac57) {
                            }
                            try {
                                _0x29ee0d[hx_0x222a(0x1ee)](hx_0x222a(0x225))['setValue'](0x64);
                            } catch (_0x32d625) {
                            }
                        }
                    } catch (_0xcb2163) {
                    }
            }
        return _arrangeSnapshot = null, app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'removed': _0x1bfaab
        });
    } catch (_0x56f7e6) {
        try {
            app['endUndoGroup']();
        } catch (_0x4352e5) {
        }
        return hx_0x222a(0x1f1) + _0x56f7e6[hx_0x222a(0x1e4)]();
    }
}
function AeEff_reseed() {
    try {
        var _0x1058b8 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x1058b8 || !(_0x1058b8 instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x15bb7f = _0x1058b8[hx_0x222a(0x1ec)];
        if (!_0x15bb7f || _0x15bb7f[hx_0x222a(0x1f2)] < 0x2)
            return hx_0x222a(0x22d);
        var _0x2436bb = [];
        for (var _0x53d37f = 0x0; _0x53d37f < _0x15bb7f[hx_0x222a(0x1f2)]; _0x53d37f++) {
            _0x2436bb[hx_0x222a(0x1f4)](_0x15bb7f[_0x53d37f]['source']);
        }
        for (var _0x127d06 = _0x2436bb['length'] - 0x1; _0x127d06 > 0x0; _0x127d06--) {
            var _0x43f83d = Math['floor'](Math[hx_0x222a(0x222)]() * (_0x127d06 + 0x1)), _0x31d259 = _0x2436bb[_0x127d06];
            _0x2436bb[_0x127d06] = _0x2436bb[_0x43f83d], _0x2436bb[_0x43f83d] = _0x31d259;
        }
        for (var _0x418a6f = 0x0; _0x418a6f < _0x15bb7f['length']; _0x418a6f++) {
            try {
                _0x15bb7f[_0x418a6f][hx_0x222a(0x22e)](_0x2436bb[_0x418a6f], ![]);
            } catch (_0x53ca1b) {
            }
        }
        return JSON['stringify']({
            'ok': !![],
            'count': _0x15bb7f['length']
        });
    } catch (_0x54e04f) {
        return 'ERR:' + _0x54e04f['toString']();
    }
}
function AeEff_growthAnimation(_0x3c8049) {
    try {
        var _0x300274 = AeEff_parseArg(_0x3c8049), _0x5ca063 = parseInt(_0x300274['dir'], 0xa);
        if (isNaN(_0x5ca063))
            _0x5ca063 = 0x0;
        var _0x50ff2b = parseInt(_0x300274[hx_0x222a(0x22f)], 0xa);
        if (isNaN(_0x50ff2b))
            _0x50ff2b = 0x0;
        var _0x43b728 = parseFloat(_0x300274['bounce']);
        if (isNaN(_0x43b728) || _0x43b728 < 0x0)
            _0x43b728 = 0.5;
        var _0x348005 = parseFloat(_0x300274[hx_0x222a(0x230)]);
        if (isNaN(_0x348005) || _0x348005 <= 0x0)
            _0x348005 = 0.3;
        var _0x2ff87c = parseFloat(_0x300274['growthStagger']);
        if (isNaN(_0x2ff87c) || _0x2ff87c < 0x0)
            _0x2ff87c = 0.2;
        var _0x17a95a = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x17a95a || !(_0x17a95a instanceof CompItem))
            return 'ERR:no_comp';
        var _0xfe7b2e = _0x17a95a['selectedLayers'];
        if (!_0xfe7b2e || _0xfe7b2e['length'] === 0x0)
            return hx_0x222a(0x1ed);
        var _0x49d1cf = 0x64, _0x4ecadf = 0x64;
        _0xfe7b2e[0x0]['source'] && (_0x49d1cf = _0xfe7b2e[0x0]['source'][hx_0x222a(0x21f)], _0x4ecadf = _0xfe7b2e[0x0][hx_0x222a(0x21e)]['height']);
        var _0x230d3c = _0x17a95a['width'] / 0x2, _0x478e84 = _0x17a95a[hx_0x222a(0x214)] / 0x2, _0x257036 = [];
        for (var _0x24f61e = 0x0; _0x24f61e < _0xfe7b2e[hx_0x222a(0x1f2)]; _0x24f61e++) {
            try {
                var _0x25959f = _0xfe7b2e[_0x24f61e]['property']('Position')['value'];
                _0x257036[hx_0x222a(0x1f4)]({
                    'layer': _0xfe7b2e[_0x24f61e],
                    'x': _0x25959f[0x0],
                    'y': _0x25959f[0x1]
                });
            } catch (_0x12ca4e) {
                _0x257036['push']({
                    'layer': _0xfe7b2e[_0x24f61e],
                    'x': _0x230d3c,
                    'y': _0x478e84
                });
            }
        }
        for (var _0x388e5c = 0x0; _0x388e5c < _0x257036[hx_0x222a(0x1f2)]; _0x388e5c++) {
            var _0x1618b5 = _0x257036[_0x388e5c];
            switch (_0x5ca063) {
            case 0x0:
                _0x1618b5[hx_0x222a(0x231)] = _0x1618b5['x'];
                break;
            case 0x1:
                _0x1618b5[hx_0x222a(0x231)] = -_0x1618b5['x'];
                break;
            case 0x2:
                _0x1618b5[hx_0x222a(0x231)] = _0x1618b5['y'];
                break;
            case 0x3:
                _0x1618b5[hx_0x222a(0x231)] = -_0x1618b5['y'];
                break;
            case 0x4:
                _0x50ff2b === 0x0 ? _0x1618b5['order'] = Math[hx_0x222a(0x232)]((_0x1618b5['x'] - _0x230d3c) * (_0x1618b5['x'] - _0x230d3c) + (_0x1618b5['y'] - _0x478e84) * (_0x1618b5['y'] - _0x478e84)) : _0x1618b5['order'] = Math['abs'](_0x1618b5['x'] - _0x230d3c) + Math['abs'](_0x1618b5['y'] - _0x478e84);
                break;
            case 0x5:
                _0x50ff2b === 0x0 ? _0x1618b5[hx_0x222a(0x231)] = -Math[hx_0x222a(0x232)]((_0x1618b5['x'] - _0x230d3c) * (_0x1618b5['x'] - _0x230d3c) + (_0x1618b5['y'] - _0x478e84) * (_0x1618b5['y'] - _0x478e84)) : _0x1618b5[hx_0x222a(0x231)] = -(Math[hx_0x222a(0x233)](_0x1618b5['x'] - _0x230d3c) + Math[hx_0x222a(0x233)](_0x1618b5['y'] - _0x478e84));
                break;
            }
        }
        _0x257036[hx_0x222a(0x234)](function (_0x2bc547, _0x153e41) {
            return _0x2bc547[hx_0x222a(0x231)] - _0x153e41[hx_0x222a(0x231)];
        });
        var _0xe997b1 = _0x17a95a[hx_0x222a(0x235)], _0x28c168 = [], _0x4baa32 = [_0x257036[0x0]], _0x5693d6 = _0x257036[0x0]['order'], _0x3af4aa = Math['max'](_0x49d1cf, _0x4ecadf) * 0.5;
        for (var _0x1c9e3b = 0x1; _0x1c9e3b < _0x257036['length']; _0x1c9e3b++) {
            Math[hx_0x222a(0x233)](_0x257036[_0x1c9e3b]['order'] - _0x5693d6) < _0x3af4aa ? _0x4baa32[hx_0x222a(0x1f4)](_0x257036[_0x1c9e3b]) : (_0x28c168['push'](_0x4baa32), _0x4baa32 = [_0x257036[_0x1c9e3b]], _0x5693d6 = _0x257036[_0x1c9e3b][hx_0x222a(0x231)]);
        }
        _0x28c168[hx_0x222a(0x1f4)](_0x4baa32), app[hx_0x222a(0x20e)](hx_0x222a(0x236));
        try {
            for (var _0x27cf0a = 0x0; _0x27cf0a < _0x28c168['length']; _0x27cf0a++) {
                var _0x3012e2 = _0xe997b1 + _0x27cf0a * _0x2ff87c, _0x25bd17 = _0x3012e2 + _0x348005;
                for (var _0x41ebe9 = 0x0; _0x41ebe9 < _0x28c168[_0x27cf0a]['length']; _0x41ebe9++) {
                    var _0x44053c = _0x28c168[_0x27cf0a][_0x41ebe9][hx_0x222a(0x204)];
                    try {
                        var _0x1481b1 = _0x44053c['property'](hx_0x222a(0x223));
                        while (_0x1481b1[hx_0x222a(0x237)] > 0x0) {
                            _0x1481b1['removeKey'](0x1);
                        }
                        _0x1481b1[hx_0x222a(0x238)](_0x3012e2, [
                            0x0,
                            0x0
                        ]);
                        var _0x3ca02f = _0x3012e2 + _0x348005 * 0.6, _0x506475 = _0x3012e2 + _0x348005 * 0.85, _0x312e4e = _0x25bd17 + _0x43b728 * 0.5, _0x101e6c = _0x25bd17 + _0x43b728;
                        if (_0x43b728 > 0x0) {
                            var _0xeb7a29 = 0x64 + _0x43b728 * 0x19, _0x4b5f28 = 0x64 - _0x43b728 * 0x8;
                            _0x1481b1[hx_0x222a(0x238)](_0x3ca02f, [
                                _0xeb7a29 * 0.6,
                                _0xeb7a29 * 0.6
                            ]), _0x1481b1['setValueAtTime'](_0x506475, [
                                _0xeb7a29,
                                _0xeb7a29
                            ]), _0x1481b1[hx_0x222a(0x238)](_0x312e4e, [
                                _0x4b5f28,
                                _0x4b5f28
                            ]), _0x1481b1['setValueAtTime'](_0x101e6c, [
                                0x64,
                                0x64
                            ]);
                        } else
                            _0x1481b1['setValueAtTime'](_0x25bd17, [
                                0x64,
                                0x64
                            ]);
                        var _0x5ee785 = new KeyframeEase(0x50, 0x14), _0x4a1777 = new KeyframeEase(0x14, 0x50), _0x4884ba = new KeyframeEase(0x32, 0x32);
                        for (var _0x401c95 = 0x1; _0x401c95 <= _0x1481b1[hx_0x222a(0x237)]; _0x401c95++) {
                            if (_0x401c95 === 0x1)
                                _0x1481b1[hx_0x222a(0x239)](_0x401c95, [
                                    _0x4a1777,
                                    _0x4a1777
                                ], [
                                    _0x4a1777,
                                    _0x4a1777
                                ]);
                            else
                                _0x401c95 === _0x1481b1[hx_0x222a(0x237)] ? _0x1481b1['setTemporalEaseAtKey'](_0x401c95, [
                                    _0x5ee785,
                                    _0x5ee785
                                ], [
                                    _0x5ee785,
                                    _0x5ee785
                                ]) : _0x1481b1['setTemporalEaseAtKey'](_0x401c95, [
                                    _0x4884ba,
                                    _0x4884ba
                                ], [
                                    _0x4884ba,
                                    _0x4884ba
                                ]);
                        }
                    } catch (_0x102470) {
                    }
                }
            }
        } catch (_0xfba732) {
        }
        return app['endUndoGroup'](), JSON['stringify']({
            'ok': !![],
            'layers': _0x257036['length'],
            'waves': _0x28c168['length']
        });
    } catch (_0x4c6880) {
        try {
            app[hx_0x222a(0x202)]();
        } catch (_0x587e7d) {
        }
        return hx_0x222a(0x1f1) + _0x4c6880[hx_0x222a(0x1e4)]();
    }
}
function _aeffCollectNames(_0x12ac83) {
    var _0x38af03 = [];
    for (var _0x142e8d = 0x0; _0x142e8d < _0x12ac83[hx_0x222a(0x1f2)]; _0x142e8d++) {
        _0x38af03[hx_0x222a(0x1f4)](_0x12ac83[_0x142e8d][hx_0x222a(0x1fd)]);
    }
    return _0x38af03;
}
function AeEff_refreshReplaceComps() {
    try {
        _replaceComps = [];
        var _0x52bcff = app['project'][hx_0x222a(0x23a)];
        for (var _0x579790 = 0x0; _0x579790 < _0x52bcff[hx_0x222a(0x1f2)]; _0x579790++) {
            _0x52bcff[_0x579790] instanceof CompItem && _replaceComps['push'](_0x52bcff[_0x579790]);
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'count': _replaceComps[hx_0x222a(0x1f2)],
            'names': _aeffCollectNames(_replaceComps)
        });
    } catch (_0x4e612d) {
        return 'ERR:' + _0x4e612d[hx_0x222a(0x1e4)]();
    }
}
function AeEff_clearReplaceComps() {
    return _replaceComps = [], 'ok';
}
function _aeffAddFootages(_0x4b3bbc) {
    var _0x23466a = app[hx_0x222a(0x1f6)]['selection'];
    for (var _0x33a4d4 = 0x0; _0x33a4d4 < _0x23466a[hx_0x222a(0x1f2)]; _0x33a4d4++) {
        if (_0x23466a[_0x33a4d4] instanceof FootageItem) {
            var _0x169459 = ![];
            for (var _0x1e18c0 = 0x0; _0x1e18c0 < _0x4b3bbc[hx_0x222a(0x1f2)]; _0x1e18c0++) {
                if (_0x4b3bbc[_0x1e18c0]['id'] === _0x23466a[_0x33a4d4]['id']) {
                    _0x169459 = !![];
                    break;
                }
            }
            !_0x169459 && _0x4b3bbc[hx_0x222a(0x1f4)](_0x23466a[_0x33a4d4]);
        }
    }
}
function AeEff_addSkinFootages() {
    try {
        return _aeffAddFootages(_replaceSkins), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'count': _replaceSkins['length'],
            'names': _aeffCollectNames(_replaceSkins)
        });
    } catch (_0x2f2b62) {
        return 'ERR:' + _0x2f2b62[hx_0x222a(0x1e4)]();
    }
}
function AeEff_addBaseFootages() {
    try {
        return _aeffAddFootages(_replaceBases), JSON['stringify']({
            'ok': !![],
            'count': _replaceBases[hx_0x222a(0x1f2)],
            'names': _aeffCollectNames(_replaceBases)
        });
    } catch (_0x25ec5a) {
        return 'ERR:' + _0x25ec5a[hx_0x222a(0x1e4)]();
    }
}
function AeEff_clearSkins() {
    return _replaceSkins = [], 'ok';
}
function AeEff_clearBases() {
    return _replaceBases = [], 'ok';
}
function AeEff_batchReplace(_0x44d800) {
    try {
        var _0x323f68 = AeEff_parseArg(_0x44d800), _0x173907 = (_0x323f68['skinKw'] || hx_0x222a(0x23b))['toString']()['toLowerCase'](), _0x1e68aa = (_0x323f68[hx_0x222a(0x23c)] || hx_0x222a(0x23d))['toString']()[hx_0x222a(0x23e)]();
        if (_replaceComps['length'] === 0x0)
            return 'ERR:no_comp';
        var _0x323a45 = _replaceSkins[hx_0x222a(0x1f2)] > 0x0, _0x4ebbb4 = _replaceBases['length'] > 0x0;
        if (!_0x323a45 && !_0x4ebbb4)
            return 'ERR:no_material';
        var _0x43838d = 0x0, _0x3f7880 = 0x0;
        for (var _0x57c27e = 0x0; _0x57c27e < _replaceComps[hx_0x222a(0x1f2)]; _0x57c27e++) {
            var _0x20f495 = _replaceComps[_0x57c27e], _0xc7dd7b = _0x323a45 ? Math[hx_0x222a(0x23f)](_0x57c27e, _replaceSkins[hx_0x222a(0x1f2)] - 0x1) : -0x1, _0x4a2c74 = _0x4ebbb4 ? Math[hx_0x222a(0x23f)](_0x57c27e, _replaceBases['length'] - 0x1) : -0x1, _0x92c56 = _0x323a45 ? _replaceSkins[_0xc7dd7b] : null, _0x2e06ff = _0x4ebbb4 ? _replaceBases[_0x4a2c74] : null, _0x3b0f81 = _0x20f495[hx_0x222a(0x208)];
            for (var _0x4eb8ef = 0x1; _0x4eb8ef <= _0x3b0f81[hx_0x222a(0x1f2)]; _0x4eb8ef++) {
                var _0xb91862 = _0x3b0f81[_0x4eb8ef], _0x27dc3c = _0xb91862[hx_0x222a(0x1fd)][hx_0x222a(0x23e)]();
                try {
                    if (_0x323a45 && _0x27dc3c['indexOf'](_0x173907) >= 0x0)
                        _0xb91862['replaceSource'](_0x92c56, ![]), _0x43838d++;
                    else
                        _0x4ebbb4 && _0x27dc3c[hx_0x222a(0x240)](_0x1e68aa) >= 0x0 && (_0xb91862[hx_0x222a(0x22e)](_0x2e06ff, ![]), _0x3f7880++);
                } catch (_0x51f1f1) {
                }
            }
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'comps': _replaceComps[hx_0x222a(0x1f2)],
            'skin': _0x43838d,
            'base': _0x3f7880
        });
    } catch (_0x42e426) {
        return hx_0x222a(0x1f1) + _0x42e426[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getFolderList() {
    try {
        var _0x25e73c = [
            hx_0x222a(0x241),
            hx_0x222a(0x242),
            hx_0x222a(0x243),
            hx_0x222a(0x244),
            hx_0x222a(0x245),
            hx_0x222a(0x246),
            hx_0x222a(0x247),
            '08_Ending',
            '09_动画预演'
        ];
        if (app[hx_0x222a(0x1e3)][hx_0x222a(0x248)](hx_0x222a(0x1e1), 'FolderList')) {
            var _0x199623 = app[hx_0x222a(0x1e3)]['getSetting']('AeEfficiencyTool', hx_0x222a(0x249));
            if (_0x199623 && _0x199623[hx_0x222a(0x1f2)] > 0x0)
                return _0x199623;
        }
        return _0x25e73c[hx_0x222a(0x24a)]('|||');
    } catch (_0x5be645) {
        return hx_0x222a(0x1f1) + _0x5be645['toString']();
    }
}
function AeEff_setFolderList(_0x1d773e) {
    try {
        return app[hx_0x222a(0x1e3)][hx_0x222a(0x218)]('AeEfficiencyTool', hx_0x222a(0x249), _0x1d773e), 'ok';
    } catch (_0x2feb9f) {
        return 'ERR:' + _0x2feb9f[hx_0x222a(0x1e4)]();
    }
}
function AeEff_createProjectFolders(_0x3d5d87) {
    try {
        if (!app[hx_0x222a(0x1f6)])
            return hx_0x222a(0x24b);
        var _0x159907 = (_0x3d5d87 || '')['split'](hx_0x222a(0x24c)), _0x7f071a = 0x0, _0x66dfbc = 0x0, _0x4a0e4a = 0x0;
        for (var _0x28c21c = 0x0; _0x28c21c < _0x159907[hx_0x222a(0x1f2)]; _0x28c21c++) {
            var _0x76c83 = (_0x159907[_0x28c21c] || '')[hx_0x222a(0x1dd)](/^\s+|\s+$/g, '');
            if (_0x76c83[hx_0x222a(0x1f2)] === 0x0)
                continue;
            var _0x3d6874 = null;
            for (var _0x1e1591 = 0x1; _0x1e1591 <= app['project'][hx_0x222a(0x1fe)][hx_0x222a(0x1f2)]; _0x1e1591++) {
                var _0x47262a = app['project'][hx_0x222a(0x1fe)][_0x1e1591];
                if (_0x47262a instanceof FolderItem && _0x47262a['name'] === _0x76c83) {
                    _0x3d6874 = _0x47262a;
                    break;
                }
            }
            if (_0x3d6874)
                _0x66dfbc++;
            else
                try {
                    var _0x3aaa5d = app[hx_0x222a(0x1f6)][hx_0x222a(0x1fe)][hx_0x222a(0x1ff)](_0x76c83);
                    _0x3aaa5d ? _0x7f071a++ : _0x4a0e4a++;
                } catch (_0x3fdc61) {
                    _0x4a0e4a++;
                }
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'created': _0x7f071a,
            'existed': _0x66dfbc,
            'failed': _0x4a0e4a
        });
    } catch (_0x189f03) {
        return 'ERR:' + _0x189f03['toString']();
    }
}
function AeEff_addMarkers(_0x3d530e, _0x2dd9cd) {
    try {
        var _0x431455 = AeEff_parseArg(_0x3d530e);
        if (!_0x431455 || typeof _0x431455['length'] !== hx_0x222a(0x24d) || _0x431455[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x24e);
        var _0x11f67f = app['project']['activeItem'];
        if (!_0x11f67f || !(_0x11f67f instanceof CompItem))
            return 'ERR:no_comp';
        var _0x49837c = _0x11f67f['selectedLayers'];
        if (!_0x49837c || _0x49837c[hx_0x222a(0x1f2)] === 0x0)
            return 'ERR:no_layer';
        app['beginUndoGroup']('添加' + _0x2dd9cd + '标记');
        var _0x12ac4e = 0x0, _0x321973 = _0x11f67f[hx_0x222a(0x24f)], _0xa53acf = 0x0;
        for (var _0x5e908d = 0x0; _0x5e908d < _0x49837c[hx_0x222a(0x1f2)]; _0x5e908d++) {
            var _0xba80c3 = _0x49837c[_0x5e908d], _0x3ab320 = _0xba80c3[hx_0x222a(0x1ee)](hx_0x222a(0x250));
            if (!_0x3ab320)
                try {
                    _0x3ab320 = _0xba80c3[hx_0x222a(0x251)]('Marker');
                } catch (_0x5c95cc) {
                    continue;
                }
            if (!_0x3ab320)
                continue;
            for (var _0x2bfd07 = 0x0; _0x2bfd07 < _0x431455[hx_0x222a(0x1f2)]; _0x2bfd07++) {
                try {
                    var _0x411770 = parseFloat(_0x431455[_0x2bfd07]);
                    if (isNaN(_0x411770))
                        continue;
                    var _0x4dd07d = new MarkerValue(_0x2dd9cd), _0x32262b = _0x411770 - _0xa53acf * _0x321973;
                    _0x32262b < 0x0 && (_0x32262b = 0x0), _0x3ab320['setValueAtTime'](_0x32262b, _0x4dd07d), _0x12ac4e++;
                } catch (_0x17e714) {
                }
            }
        }
        return app['endUndoGroup'](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'count': _0x12ac4e,
            'label': _0x2dd9cd
        });
    } catch (_0xb21aca) {
        return hx_0x222a(0x1f1) + _0xb21aca[hx_0x222a(0x1e4)]();
    }
}
function AeEff_addMoveMarkers(_0xe4369d) {
    try {
        var _0x301a94 = AeEff_parseArg(_0xe4369d);
        if (!_0x301a94 || typeof _0x301a94[hx_0x222a(0x1f2)] !== hx_0x222a(0x24d) || _0x301a94[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x24e);
        var _0x239f86 = app[hx_0x222a(0x1f6)]['activeItem'];
        if (!_0x239f86 || !(_0x239f86 instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x1dfe2e = _0x239f86['selectedLayers'];
        if (!_0x1dfe2e || _0x1dfe2e['length'] === 0x0)
            return hx_0x222a(0x1ed);
        app['beginUndoGroup']('添加移动标记');
        var _0x2bb8bb = 0x0, _0x2f254f = _0x239f86[hx_0x222a(0x24f)];
        for (var _0x1fbfb6 = 0x0; _0x1fbfb6 < _0x1dfe2e[hx_0x222a(0x1f2)]; _0x1fbfb6++) {
            var _0x47b3ea = _0x1dfe2e[_0x1fbfb6], _0x41f6de = _0x47b3ea[hx_0x222a(0x1ee)]('Marker');
            if (!_0x41f6de)
                try {
                    _0x41f6de = _0x47b3ea[hx_0x222a(0x251)](hx_0x222a(0x250));
                } catch (_0x561b2d) {
                    continue;
                }
            for (var _0x280365 = 0x0; _0x280365 < _0x301a94[hx_0x222a(0x1f2)]; _0x280365++) {
                try {
                    var _0x15ecdc = parseFloat(_0x301a94[_0x280365]);
                    if (isNaN(_0x15ecdc))
                        continue;
                    var _0x3d07d4 = _0x15ecdc - 0x6 * _0x2f254f;
                    _0x3d07d4 < 0x0 && (_0x3d07d4 = 0x0);
                    var _0x4fd9c1 = new MarkerValue('移动');
                    _0x41f6de[hx_0x222a(0x238)](_0x3d07d4, _0x4fd9c1), _0x2bb8bb++;
                } catch (_0x5bfe37) {
                }
            }
        }
        return app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'count': _0x2bb8bb,
            'label': '移动'
        });
    } catch (_0x17ed5b) {
        return 'ERR:' + _0x17ed5b[hx_0x222a(0x1e4)]();
    }
}
function AeEff_escStr(_0x31155a) {
    _0x31155a = String(_0x31155a);
    var _0x23b7f9 = '';
    for (var _0x11e329 = 0x0; _0x11e329 < _0x31155a[hx_0x222a(0x1f2)]; _0x11e329++) {
        var _0x42473b = _0x31155a['charAt'](_0x11e329);
        if (_0x42473b === '\x22')
            _0x23b7f9 += '\x5c\x22';
        else
            _0x42473b === '\x5c' ? _0x23b7f9 += '\x5c\x5c' : _0x23b7f9 += _0x42473b;
    }
    return _0x23b7f9;
}
function AeEff_buildCounterExpr(_0x4b32cd, _0x426de8, _0x3d8a1b, _0x284999, _0x301a76, _0x309210) {
    var _0x35c6e6 = [];
    return _0x35c6e6['push'](hx_0x222a(0x252) + AeEff_escStr(_0x4b32cd) + '\x22);'), _0x35c6e6[hx_0x222a(0x1f4)]('var\x20pc\x20=\x20outComp.layer(\x22' + AeEff_escStr(_0x426de8) + '\x22);'), _0x35c6e6[hx_0x222a(0x1f4)]('var\x20mk\x20=\x20pc.marker;'), _0x35c6e6['push'](hx_0x222a(0x253) + _0x3d8a1b + ';'), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x254) + _0x284999 + ';'), _0x35c6e6['push']('var\x20dur\x20=\x20' + _0x301a76 + ';'), _0x35c6e6['push'](hx_0x222a(0x255) + (_0x309210 ? 'true' : 'false') + ';'), _0x35c6e6[hx_0x222a(0x1f4)]('function\x20fmtNum(v)\x20{'), _0x35c6e6['push'](hx_0x222a(0x256)), _0x35c6e6[hx_0x222a(0x1f4)]('\x20\x20var\x20neg\x20=\x20\x22\x22;'), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x257)), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x258)), _0x35c6e6[hx_0x222a(0x1f4)]('\x20\x20for\x20(var\x20i\x20=\x20s.length\x20-\x201;\x20i\x20>=\x200;\x20i--)\x20{'), _0x35c6e6[hx_0x222a(0x1f4)]('\x20\x20\x20\x20out\x20=\x20s.charAt(i)\x20+\x20out;\x20cnt++;'), _0x35c6e6[hx_0x222a(0x1f4)]('\x20\x20\x20\x20if\x20(cnt\x20%\x203\x20===\x200\x20&&\x20i\x20>\x200)\x20{\x20out\x20=\x20\x22,\x22\x20+\x20out;\x20}'), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x259)), _0x35c6e6['push'](hx_0x222a(0x25a)), _0x35c6e6[hx_0x222a(0x1f4)]('}'), _0x35c6e6['push'](hx_0x222a(0x25b)), _0x35c6e6['push'](hx_0x222a(0x25c)), _0x35c6e6[hx_0x222a(0x1f4)]('for\x20(var\x20i\x20=\x201;\x20i\x20<=\x20n;\x20i++)\x20{\x20if\x20(t\x20>=\x20mk.key(i).time)\x20idx++;\x20}'), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x25d)), _0x35c6e6['push'](hx_0x222a(0x25e)), _0x35c6e6['push']('}\x20else\x20{'), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x25f)), _0x35c6e6[hx_0x222a(0x1f4)]('\x20\x20var\x20curVal\x20=\x20base\x20+\x20idx\x20*\x20step;'), _0x35c6e6['push'](hx_0x222a(0x260)), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x261)), _0x35c6e6['push']('\x20\x20if\x20(t\x20<\x20tA\x20+\x20dur)\x20{'), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x262)), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x263)), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x264)), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x265)), _0x35c6e6[hx_0x222a(0x1f4)](hx_0x222a(0x266)), _0x35c6e6[hx_0x222a(0x1f4)]('\x20\x20}'), _0x35c6e6['push'](hx_0x222a(0x267)), _0x35c6e6['push']('}'), _0x35c6e6[hx_0x222a(0x24a)]('\x0a');
}
function AeEff_buildScaleExpr(_0x2676d8, _0x425e60) {
    var _0x1a0273 = [];
    return _0x1a0273['push'](hx_0x222a(0x268)), _0x1a0273['push'](hx_0x222a(0x269) + _0x2676d8 + ';'), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x26a) + _0x425e60 + ';'), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x25b)), _0x1a0273['push'](hx_0x222a(0x25c)), _0x1a0273['push'](hx_0x222a(0x26b)), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x26c)), _0x1a0273['push']('if\x20(idx\x20>=\x201)\x20{'), _0x1a0273[hx_0x222a(0x1f4)]('\x20\x20var\x20tA\x20=\x20mk.key(idx).time;'), _0x1a0273['push'](hx_0x222a(0x26d)), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x26e)), _0x1a0273['push']('\x20\x20\x20\x20var\x20p\x20=\x20dt\x20/\x20popDur;'), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x26f)), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x270)), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x259)), _0x1a0273['push']('}'), _0x1a0273[hx_0x222a(0x1f4)]('var\x20base\x20=\x20value;'), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x271)), _0x1a0273['push'](hx_0x222a(0x272)), _0x1a0273[hx_0x222a(0x1f4)](hx_0x222a(0x273)), _0x1a0273[hx_0x222a(0x24a)]('\x0a');
}
function hx_0x222a(_0x550456, _0x38a8f2) {
    _0x550456 = _0x550456 - 0x1dc;
    var _0x222a4c = hx_0x38a8();
    var _0x2dccfe = _0x222a4c[_0x550456];
    return _0x2dccfe;
}
function AeEff_chooseTextLayer(_0xc1ac6f) {
    var _0x2da5df = new Window('dialog', hx_0x222a(0x274));
    _0x2da5df[hx_0x222a(0x275)] = hx_0x222a(0x276), _0x2da5df[hx_0x222a(0x277)] = [
        hx_0x222a(0x278),
        'top'
    ], _0x2da5df['margins'] = [
        0xc,
        0xc,
        0xc,
        0xc
    ], _0x2da5df['add'](hx_0x222a(0x279), undefined, '预合成内有多个文字图层，请选择目标：');
    var _0x491627 = _0x2da5df[hx_0x222a(0x27a)]('listbox', undefined, [], {
        'numberOfColumns': 0x1,
        'showHeaders': ![]
    });
    _0x491627['preferredSize'] = [
        0x104,
        0x78
    ];
    for (var _0x49dc3b = 0x0; _0x49dc3b < _0xc1ac6f[hx_0x222a(0x1f2)]; _0x49dc3b++) {
        _0x491627[hx_0x222a(0x27a)](hx_0x222a(0x27b), _0xc1ac6f[_0x49dc3b]['name']);
    }
    var _0x5a451d = _0x2da5df[hx_0x222a(0x27a)]('group');
    _0x5a451d['orientation'] = hx_0x222a(0x27c), _0x5a451d[hx_0x222a(0x27d)] = [
        'right',
        hx_0x222a(0x27e)
    ];
    var _0x24df1b = _0x5a451d['add']('button', undefined, '确定'), _0x5aacfc = _0x5a451d[hx_0x222a(0x27a)]('button', undefined, '取消'), _0x67e25c = null;
    return _0x24df1b[hx_0x222a(0x27f)] = function () {
        if (_0x491627[hx_0x222a(0x23a)]) {
            if (typeof _0x491627[hx_0x222a(0x23a)]['index'] === 'number')
                _0x67e25c = _0x491627['selection'][hx_0x222a(0x280)];
            else
                for (var _0x16208c = 0x0; _0x16208c < _0x491627[hx_0x222a(0x1fe)]['length']; _0x16208c++) {
                    if (_0x491627['items'][_0x16208c] === _0x491627['selection']) {
                        _0x67e25c = _0x16208c;
                        break;
                    }
                }
            _0x2da5df[hx_0x222a(0x281)](0x1);
        }
    }, _0x5aacfc[hx_0x222a(0x27f)] = function () {
        _0x2da5df['close'](0x0);
    }, _0x2da5df[hx_0x222a(0x282)](), _0x67e25c;
}
function AeEff_applyNumberCounter(_0x551cf5) {
    try {
        var _0x5b66da = AeEff_parseArg(_0x551cf5), _0xe49356 = parseFloat(_0x5b66da['step']);
        (isNaN(_0xe49356) || _0xe49356 === 0x0) && (_0xe49356 = 0x32);
        var _0x4fa1ec = parseFloat(_0x5b66da['dur']);
        (isNaN(_0x4fa1ec) || _0x4fa1ec <= 0x0) && (_0x4fa1ec = 0x1);
        var _0x4a2423 = !!_0x5b66da[hx_0x222a(0x283)], _0x147db4 = parseFloat(_0x5b66da[hx_0x222a(0x284)]);
        (isNaN(_0x147db4) || _0x147db4 < 0x0) && (_0x147db4 = 0x0);
        var _0x4fc33d = Math[hx_0x222a(0x23f)](_0x4fa1ec, Math[hx_0x222a(0x285)](0.3, 0.6)), _0x4bc434 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x4bc434 || !(_0x4bc434 instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x3c9f24 = _0x4bc434[hx_0x222a(0x1ec)];
        if (!_0x3c9f24 || _0x3c9f24[hx_0x222a(0x1f2)] !== 0x1)
            return hx_0x222a(0x286);
        var _0x56e52e = _0x3c9f24[0x0], _0x3858c9 = _0x56e52e[hx_0x222a(0x21e)];
        if (!_0x3858c9 || !(_0x3858c9 instanceof CompItem))
            return hx_0x222a(0x287);
        var _0x526dcf = [];
        for (var _0x287437 = 0x1; _0x287437 <= _0x3858c9['layers']['length']; _0x287437++) {
            var _0x4f6349 = _0x3858c9[hx_0x222a(0x208)][_0x287437];
            _0x4f6349 instanceof TextLayer && _0x526dcf['push'](_0x4f6349);
        }
        if (_0x526dcf[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x288);
        var _0x3af439 = null;
        if (_0x526dcf['length'] === 0x1)
            _0x3af439 = _0x526dcf[0x0];
        else {
            var _0x22004f = AeEff_chooseTextLayer(_0x526dcf);
            if (_0x22004f === null || _0x22004f === undefined)
                return hx_0x222a(0x289);
            _0x3af439 = _0x526dcf[_0x22004f];
        }
        var _0x220d8b = '';
        try {
            var _0x237ff1 = _0x3af439[hx_0x222a(0x1ee)](hx_0x222a(0x1ef))[hx_0x222a(0x1f3)];
            _0x237ff1 && _0x237ff1[hx_0x222a(0x28a)] && (_0x220d8b = _0x237ff1[hx_0x222a(0x28a)]);
        } catch (_0x19ab3a) {
        }
        var _0x5788bc = parseFloat(String(_0x220d8b)['replace'](/,/g, ''));
        if (isNaN(_0x5788bc))
            return 'ERR:base_not_number';
        app[hx_0x222a(0x20e)]('数字累加表达式');
        try {
            try {
                var _0x90500a = _0x3af439['property']('Source\x20Text')['value'];
                if (_0x90500a && !_0x90500a[hx_0x222a(0x28b)]) {
                    var _0x3126ec = _0x3af439[hx_0x222a(0x28c)](_0x3af439['containingComp']['time'], ![]), _0x12ac2a = _0x3126ec && _0x3126ec[hx_0x222a(0x21f)] ? _0x3126ec[hx_0x222a(0x21f)] : _0x90500a['fontSize'] || 0x28, _0x302059 = _0x3126ec && _0x3126ec['height'] ? _0x3126ec['height'] : _0x90500a['fontSize'] || 0x28, _0x6d6831 = Math[hx_0x222a(0x285)](_0x12ac2a * 0x3, _0x12ac2a + 0x258, 0x320), _0xdb8c46 = Math[hx_0x222a(0x285)](_0x302059 * 0x2, 0x3c), _0x188a18 = _0x6d6831 / 0x2 - _0x12ac2a / 0x2;
                    _0x90500a[hx_0x222a(0x28b)] = !![], _0x90500a['boxTextSize'] = [
                        _0x6d6831,
                        _0xdb8c46
                    ], _0x90500a['justification'] = ParagraphJustification[hx_0x222a(0x28d)], _0x90500a['verticalJustification'] = VerticalJustification[hx_0x222a(0x28e)], _0x3af439[hx_0x222a(0x1ee)](hx_0x222a(0x1ef))['setValue'](_0x90500a);
                    if (_0x3af439['anchorPoint']['numKeys'] === 0x0 && !_0x3af439[hx_0x222a(0x28f)]['expression'] && _0x3af439['position'][hx_0x222a(0x237)] === 0x0 && !_0x3af439[hx_0x222a(0x290)][hx_0x222a(0x291)]) {
                        var _0x2cb95a = _0x3af439['anchorPoint'][hx_0x222a(0x1f3)];
                        if (_0x2cb95a && _0x2cb95a[hx_0x222a(0x1f2)] >= 0x2)
                            _0x3af439[hx_0x222a(0x28f)][hx_0x222a(0x217)]([
                                _0x2cb95a[0x0] + _0x188a18,
                                _0x2cb95a[0x1]
                            ]);
                        var _0x1a3a4f = _0x3af439['position'][hx_0x222a(0x1f3)];
                        if (_0x1a3a4f && _0x1a3a4f[hx_0x222a(0x1f2)] === 0x3)
                            _0x3af439[hx_0x222a(0x290)][hx_0x222a(0x217)]([
                                _0x1a3a4f[0x0] + _0x188a18,
                                _0x1a3a4f[0x1],
                                _0x1a3a4f[0x2]
                            ]);
                        else
                            _0x1a3a4f && _0x1a3a4f['length'] === 0x2 && _0x3af439[hx_0x222a(0x290)][hx_0x222a(0x217)]([
                                _0x1a3a4f[0x0] + _0x188a18,
                                _0x1a3a4f[0x1]
                            ]);
                    }
                } else
                    _0x90500a['justification'] = ParagraphJustification[hx_0x222a(0x28d)], _0x3af439[hx_0x222a(0x1ee)](hx_0x222a(0x1ef))[hx_0x222a(0x217)](_0x90500a);
            } catch (_0x9330e7) {
            }
            var _0x45e4ee = _0x3af439[hx_0x222a(0x1ee)](hx_0x222a(0x1ef));
            _0x45e4ee[hx_0x222a(0x291)] = AeEff_buildCounterExpr(_0x4bc434[hx_0x222a(0x1fd)], _0x56e52e['name'], _0x5788bc, _0xe49356, _0x4fa1ec, _0x4a2423);
            var _0x439b59 = _0x56e52e[hx_0x222a(0x1ee)]('Scale'), _0x5db83f = _0x3af439['property']('Scale'), _0x45203c = _0x3af439[hx_0x222a(0x1ee)]('Position');
            if (_0x147db4 > 0x0) {
                try {
                    _0x439b59[hx_0x222a(0x291)] = AeEff_buildScaleExpr(_0x147db4, _0x4fc33d);
                } catch (_0x28ca6c) {
                }
                try {
                    _0x5db83f[hx_0x222a(0x291)] && (_0x5db83f['expression'] = '');
                } catch (_0x5d1a36) {
                }
                try {
                    _0x45203c['expression'] && (_0x45203c['expression'] = '');
                } catch (_0x4a9d88) {
                }
            } else {
                try {
                    _0x439b59[hx_0x222a(0x291)] && (_0x439b59[hx_0x222a(0x291)] = '');
                } catch (_0xe33ef5) {
                }
                try {
                    _0x5db83f[hx_0x222a(0x291)] && (_0x5db83f['expression'] = '');
                } catch (_0x455119) {
                }
                try {
                    _0x45203c[hx_0x222a(0x291)] && (_0x45203c['expression'] = '');
                } catch (_0x298436) {
                }
            }
        } catch (_0x4d26fd) {
            return app[hx_0x222a(0x202)](), hx_0x222a(0x292) + _0x4d26fd[hx_0x222a(0x1e4)]();
        }
        return app[hx_0x222a(0x202)](), JSON['stringify']({
            'ok': !![],
            'base': _0x5788bc,
            'step': _0xe49356,
            'dur': _0x4fa1ec,
            'sep': _0x4a2423,
            'scaleAmt': _0x147db4
        });
    } catch (_0x3e7e6b) {
        return 'ERR:' + _0x3e7e6b[hx_0x222a(0x1e4)]();
    }
}
var AeEff_BUILTIN_EXPR_LIB = [
    {
        'name': '拿起/放下/消除',
        'expr': 'src\x20=\x20comp(name).layer(\x22控制器\x22);\x0an\x20=\x200;\x0a\x0aif\x20(marker.numKeys\x20>\x200)\x20{\x0a\x20\x20\x20\x20n\x20=\x20marker.nearestKey(time).index;\x0a\x20\x20\x20\x20if\x20(marker.key(n).time\x20>\x20time)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20n--;\x0a\x20\x20\x20\x20}\x0a}\x0a\x0aif\x20(n\x20==\x200)\x20{\x0a\x20\x20\x20\x200;\x0a}\x20else\x20{\x0a\x20\x20\x20\x20//\x20根据当前标记序号对\x203\x20取模，循环匹配三个状态\x0a\x20\x20\x20\x20//\x20第\x201,\x204,\x207...\x20个标记\x20->\x20拿起\x0a\x20\x20\x20\x20//\x20第\x202,\x205,\x208...\x20个标记\x20->\x20放下\x0a\x20\x20\x20\x20//\x20第\x203,\x206,\x209...\x20个标记\x20->\x20消除\x0a\x20\x20\x20\x20mod\x20=\x20n\x20%\x203;\x0a\x20\x20\x20\x20if\x20(mod\x20==\x201)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20myComment\x20=\x20\x22拿起\x22;\x0a\x20\x20\x20\x20}\x20else\x20if\x20(mod\x20==\x202)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20myComment\x20=\x20\x22放下\x22;\x0a\x20\x20\x20\x20}\x20else\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20myComment\x20=\x20\x22消除\x22;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20m\x20=\x20marker.key(n);\x0a\x20\x20\x20\x20t\x20=\x20time\x20-\x20m.time;\x0a\x0a\x20\x20\x20\x20try\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark\x20=\x20src.marker.key(myComment);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(src.marker.numKeys\x20>\x20mark.index)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20tMax\x20=\x20src.marker.key(mark.index\x20+\x201).time\x20-\x20mark.time;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x20else\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20tMax\x20=\x20src.outPoint\x20-\x20mark.time;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20t\x20=\x20Math.min(t,\x20tMax);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark.time\x20+\x20t;\x0a\x20\x20\x20\x20}\x20catch\x20(err)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x200;\x0a\x20\x20\x20\x20}\x0a}'
    },
    {
        'name': '按下',
        'expr': 'src\x20=\x20comp(name).layer(\x22控制器\x22);\x0an\x20=\x200;\x0a\x0a//\x20找到当前时间最近的一个标记点\x0aif\x20(marker.numKeys\x20>\x200)\x20{\x0a\x20\x20\x20\x20n\x20=\x20marker.nearestKey(time).index;\x0a\x20\x20\x20\x20if\x20(marker.key(n).time\x20>\x20time)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20n--;\x0a\x20\x20\x20\x20}\x0a}\x0a\x0aif\x20(n\x20==\x200)\x20{\x0a\x20\x20\x20\x200;\x0a}\x20else\x20{\x0a\x20\x20\x20\x20//\x20强制设定为查找“按下”状态\x0a\x20\x20\x20\x20myComment\x20=\x20\x22按下\x22;\x0a\x20\x20\x20\x20m\x20=\x20marker.key(n);\x0a\x20\x20\x20\x20t\x20=\x20time\x20-\x20m.time;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20try\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20//\x20在源图层中查找“按下”标记\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark\x20=\x20src.marker.key(myComment);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20//\x20计算过渡时间（如果后面还有标记则限制到下一个标记，否则到图层末尾）\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(src.marker.numKeys\x20>\x20mark.index)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20tMax\x20=\x20src.marker.key(mark.index\x20+\x201).time\x20-\x20mark.time;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x20else\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20tMax\x20=\x20src.outPoint\x20-\x20mark.time;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20t\x20=\x20Math.min(t,\x20tMax);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark.time\x20+\x20t;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20}\x20catch\x20(err)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x200;\x0a\x20\x20\x20\x20}\x0a}'
    },
    {
        'name': '按下/弹起',
        'expr': 'src\x20=\x20comp(name).layer(\x22控制器\x22);\x0an\x20=\x200;\x0aif\x20(marker.numKeys\x20>\x200)\x20{\x0a\x20\x20\x20\x20n\x20=\x20marker.nearestKey(time).index;\x0a\x20\x20\x20\x20if\x20(marker.key(n).time\x20>\x20time)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20n--;\x0a\x20\x20\x20\x20}\x0a}\x0aif\x20(n\x20==\x200)\x20{\x0a\x20\x20\x20\x200\x0a}\x20else\x20{\x0a\x09if\x20((thisLayer.marker.key(n).index\x20%\x202)\x20>\x200){\x0a\x09myComment\x20=\x20\x22按下\x22;\x0a\x09}\x20else\x20{\x0a\x09myComment\x20=\x20\x22弹起\x22;\x0a\x09\x09}\x0a\x20\x20\x20\x20m\x20=\x20marker.key(n);\x0a\x20\x20\x20\x20t\x20=\x20time\x20-\x20m.time;\x0a\x20\x20\x20\x20try\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark\x20=\x20src.marker.key(myComment);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(src.marker.numKeys\x20>\x20mark.index)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20tMax\x20=\x20src.marker.key(mark.index\x20+\x201).time\x20-\x20mark.time;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x20else\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20tMax\x20=\x20src.outPoint\x20-\x20mark.time;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20t\x20=\x20Math.min(t,\x20tMax);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark.time\x20+\x20t;\x0a\x20\x20\x20\x20}catch\x20(err)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x200\x0a\x20\x20\x20\x20}\x0a}'
    },
    {
        'name': hx_0x222a(0x293),
        'expr': hx_0x222a(0x294)
    },
    {
        'name': '数字跳动',
        'expr': '//\x20获取控制层的设置\x0avar\x20ctrl\x20=\x20thisComp.layer(\x22Null\x201\x22);\x0avar\x20num\x20=\x20ctrl.effect(\x22number\x22)(\x22Slider\x22).value;\x0avar\x20amtOfDec\x20=\x20Math.floor(ctrl.effect(\x22amt_of_decimals\x22)(\x22Slider\x22).value);\x0avar\x20useCommas\x20=\x20ctrl.effect(\x22use_commas\x22)(\x22Checkbox\x22).value\x20==\x201;\x0a\x0a//\x20格式化函数\x0afunction\x20addCommas(str)\x20{\x0a\x20\x20\x20\x20var\x20parts\x20=\x20str.split(\x22.\x22);\x0a\x20\x20\x20\x20parts[0]\x20=\x20parts[0].replace(/\x5cB(?=(\x5cd{3})+(?!\x5cd))/g,\x20\x22,\x22);\x0a\x20\x20\x20\x20return\x20parts.join(\x22.\x22);\x0a}\x0a\x0a//\x20执行逻辑\x0avar\x20result\x20=\x20num.toFixed(amtOfDec);\x0a\x0aif\x20(useCommas)\x20{\x0a\x20\x20\x20\x20result\x20=\x20addCommas(result);\x0a}\x0a\x0aresult;'
    }
];
function AeEff_arrHas(_0x59d392, _0x4d26d4) {
    for (var _0x2bcbe4 = 0x0; _0x2bcbe4 < _0x59d392['length']; _0x2bcbe4++) {
        if (_0x59d392[_0x2bcbe4] === _0x4d26d4)
            return !![];
    }
    return ![];
}
function AeEff_getExprLibDeleted() {
    try {
        if (app[hx_0x222a(0x1e3)]['haveSetting']('AeEfficiencyTool', 'ExprLibDeleted')) {
            var _0xef3c6f = app['settings'][hx_0x222a(0x1e0)](hx_0x222a(0x1e1), hx_0x222a(0x295));
            if (_0xef3c6f && _0xef3c6f[hx_0x222a(0x1f2)])
                return _0xef3c6f;
        }
    } catch (_0x1dd079) {
    }
    return '[]';
}
function AeEff_setExprLibDeleted(_0x3d054a) {
    try {
        return app[hx_0x222a(0x1e3)][hx_0x222a(0x218)](hx_0x222a(0x1e1), hx_0x222a(0x295), _0x3d054a), 'ok';
    } catch (_0x31e91f) {
        return hx_0x222a(0x1f1) + _0x31e91f['toString']();
    }
}
function AeEff_getExprLib() {
    try {
        var _0x3b546d = [];
        if (app[hx_0x222a(0x1e3)]['haveSetting']('AeEfficiencyTool', hx_0x222a(0x296))) {
            var _0x26e96d = app[hx_0x222a(0x1e3)][hx_0x222a(0x1e0)](hx_0x222a(0x1e1), hx_0x222a(0x296));
            if (_0x26e96d && _0x26e96d[hx_0x222a(0x1f2)] > 0x0)
                try {
                    var _0x29098d = JSON['parse'](_0x26e96d);
                    if (_0x29098d && (_0x29098d['length'] || _0x29098d['items']))
                        _0x3b546d = _0x29098d[hx_0x222a(0x1f2)] ? _0x29098d : _0x29098d[hx_0x222a(0x1fe)];
                } catch (_0x585f84) {
                }
        }
        var _0x5924b5 = [];
        try {
            var _0x88e7ad = AeEff_getExprLibDeleted();
            if (_0x88e7ad && _0x88e7ad[hx_0x222a(0x1f2)]) {
                var _0x201c1e = JSON['parse'](_0x88e7ad);
                if (_0x201c1e && _0x201c1e['length'])
                    _0x5924b5 = _0x201c1e;
            }
        } catch (_0x12108c) {
        }
        var _0x14a185 = {};
        for (var _0x42f018 = 0x0; _0x42f018 < _0x3b546d[hx_0x222a(0x1f2)]; _0x42f018++) {
            _0x14a185[_0x3b546d[_0x42f018]['name']] = !![];
        }
        for (var _0x54aa87 = 0x0; _0x54aa87 < AeEff_BUILTIN_EXPR_LIB[hx_0x222a(0x1f2)]; _0x54aa87++) {
            var _0x1a967f = AeEff_BUILTIN_EXPR_LIB[_0x54aa87];
            !_0x14a185[_0x1a967f[hx_0x222a(0x1fd)]] && !AeEff_arrHas(_0x5924b5, _0x1a967f['name']) && _0x3b546d['push']({
                'name': _0x1a967f['name'],
                'expr': _0x1a967f[hx_0x222a(0x297)],
                'builtin': !![]
            });
        }
        return JSON[hx_0x222a(0x228)](_0x3b546d);
    } catch (_0x5de131) {
        return 'ERR:' + _0x5de131[hx_0x222a(0x1e4)]();
    }
}
function AeEff_setExprLib(_0x17ce26) {
    try {
        return app[hx_0x222a(0x1e3)][hx_0x222a(0x218)]('AeEfficiencyTool', hx_0x222a(0x296), _0x17ce26), 'ok';
    } catch (_0x2838b1) {
        return hx_0x222a(0x1f1) + _0x2838b1[hx_0x222a(0x1e4)]();
    }
}
function AeEff_applyExpressionToSelected(_0x43a98e, _0x57a39c) {
    try {
        var _0x3f4220 = app['project'][hx_0x222a(0x1ea)];
        if (!_0x3f4220 || !(_0x3f4220 instanceof CompItem))
            return 'ERR:no_comp';
        var _0x5d7fb3 = _0x3f4220[hx_0x222a(0x298)];
        if (!_0x5d7fb3 || _0x5d7fb3[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x299);
        app[hx_0x222a(0x20e)](hx_0x222a(0x29a));
        var _0x31d106 = 0x0;
        for (var _0xa7a33 = 0x0; _0xa7a33 < _0x5d7fb3[hx_0x222a(0x1f2)]; _0xa7a33++) {
            try {
                _0x5d7fb3[_0xa7a33][hx_0x222a(0x291)] = _0x43a98e, _0x31d106++;
            } catch (_0xbe358c) {
            }
        }
        return app[hx_0x222a(0x202)](), JSON['stringify']({
            'ok': !![],
            'count': _0x31d106,
            'name': _0x57a39c
        });
    } catch (_0x1c9f18) {
        return 'ERR:' + _0x1c9f18[hx_0x222a(0x1e4)]();
    }
}
function getDefaultPaths() {
    var _0x44251d = $['os'][hx_0x222a(0x23e)]()[hx_0x222a(0x240)](hx_0x222a(0x29b)) >= 0x0, _0x511141 = {}, _0x548bac;
    _0x44251d ? (_0x511141[hx_0x222a(0x29c)] = Folder[hx_0x222a(0x29d)]['fullName'] + '/Adobe/After\x20Effects/Disk\x20Cache', _0x511141[hx_0x222a(0x29e)] = Folder['userData'][hx_0x222a(0x1fb)] + '/Adobe/Common/Media\x20Cache\x20Files', _0x548bac = Folder[hx_0x222a(0x29f)]['fullName'] + '/Adobe/Common') : (_0x511141[hx_0x222a(0x29c)] = '~/Library/Caches/Adobe/After\x20Effects', _0x511141[hx_0x222a(0x29e)] = hx_0x222a(0x2a0), _0x548bac = hx_0x222a(0x2a1));
    try {
        _0x511141[hx_0x222a(0x2a2)] = new Folder(_0x548bac)['fullName'] + hx_0x222a(0x2a3);
    } catch (_0x469ec2) {
        _0x511141['peaks'] = '';
    }
    return _0x511141;
}
function readPrefCachePath() {
    var _0x4608dc = '', _0x4accc9 = '';
    try {
        app['settings']['haveSetting'](hx_0x222a(0x2a4), 'Folder') && (_0x4608dc = app['settings'][hx_0x222a(0x1e0)](hx_0x222a(0x2a4), hx_0x222a(0x2a5)));
    } catch (_0x57dcc6) {
    }
    try {
        app['settings'][hx_0x222a(0x248)](hx_0x222a(0x2a6), hx_0x222a(0x2a7)) && (_0x4accc9 = app['settings'][hx_0x222a(0x1e0)]('Media\x20&\x20Disk\x20Cache', hx_0x222a(0x2a7)));
    } catch (_0x4a413d) {
    }
    var _0x322698 = getDefaultPaths();
    return {
        'diskCache': _0x4608dc['length'] > 0x0 ? _0x4608dc : _0x322698[hx_0x222a(0x29c)],
        'mediaCache': _0x4accc9[hx_0x222a(0x1f2)] > 0x0 ? _0x4accc9 : _0x322698[hx_0x222a(0x29e)],
        'peaks': _0x322698[hx_0x222a(0x2a2)] || ''
    };
}
function removeFolderContents(_0x3f5d26) {
    if (!_0x3f5d26 || !(_0x3f5d26 instanceof Folder) || !_0x3f5d26[hx_0x222a(0x2a8)])
        return !![];
    var _0x358b68 = _0x3f5d26[hx_0x222a(0x2a9)](), _0x2e6c41 = !![], _0x564e09 = 0x0;
    for (var _0x525f33 = 0x0; _0x525f33 < _0x358b68['length']; _0x525f33++) {
        var _0x9b2c09 = _0x358b68[_0x525f33];
        if (_0x9b2c09 instanceof Folder) {
            var _0x5106ba = removeFolderContents(_0x9b2c09);
            _0x5106ba ? !_0x9b2c09[hx_0x222a(0x21d)]() && (_0x2e6c41 = ![], _0x564e09++) : (_0x2e6c41 = ![], _0x564e09++);
        } else
            !_0x9b2c09[hx_0x222a(0x21d)]() && (_0x2e6c41 = ![], _0x564e09++);
    }
    return _0x2e6c41 && _0x564e09 === 0x0;
}
function getFolderSizeRecursive(_0x11ff71) {
    if (!_0x11ff71[hx_0x222a(0x2a8)])
        return 0x0;
    var _0x31a5df = 0x0, _0x8439a9 = _0x11ff71[hx_0x222a(0x2a9)]('*');
    for (var _0x1d943b = 0x0; _0x1d943b < _0x8439a9['length']; _0x1d943b++) {
        _0x8439a9[_0x1d943b] instanceof Folder ? _0x31a5df += getFolderSizeRecursive(_0x8439a9[_0x1d943b]) : _0x31a5df += _0x8439a9[_0x1d943b][hx_0x222a(0x1f2)];
    }
    return _0x31a5df;
}
function getFolderSizeMB(_0x3736af) {
    if (!_0x3736af['exists'])
        return 0x0;
    return Math['round'](getFolderSizeRecursive(_0x3736af) / 0x400 / 0x400 * 0xa) / 0xa;
}
function AeEff_getCacheInfo() {
    try {
        var _0x5290a6 = readPrefCachePath(), _0x336f65 = getFolderSizeMB(new Folder(_0x5290a6['diskCache'])), _0x514e32 = getFolderSizeMB(new Folder(_0x5290a6[hx_0x222a(0x29e)]));
        return JSON['stringify']({
            'diskCache': _0x5290a6['diskCache'],
            'mediaCache': _0x5290a6['mediaCache'],
            'diskSizeMB': _0x336f65,
            'mediaSizeMB': _0x514e32
        });
    } catch (_0x116114) {
        return hx_0x222a(0x1f1) + _0x116114['toString']();
    }
}
function AeEff_emptyDiskCache() {
    try {
        var _0x4d8c45 = readPrefCachePath(), _0x378371 = new Folder(_0x4d8c45[hx_0x222a(0x29c)]);
        if (!_0x378371[hx_0x222a(0x2a8)])
            return 'ERR:no_disk_cache';
        var _0x5e46dd = removeFolderContents(_0x378371);
        return JSON[hx_0x222a(0x228)]({
            'ok': _0x5e46dd,
            'diskCache': _0x4d8c45['diskCache']
        });
    } catch (_0x4d6074) {
        return hx_0x222a(0x1f1) + _0x4d6074['toString']();
    }
}
function AeEff_cleanDatabaseAndCache() {
    try {
        var _0x4bc8b6 = readPrefCachePath(), _0x31e1e0 = [], _0x59b305 = new Folder(_0x4bc8b6['mediaCache']);
        if (_0x59b305[hx_0x222a(0x2a8)])
            _0x31e1e0['push'](_0x59b305);
        if (_0x4bc8b6[hx_0x222a(0x2a2)]) {
            var _0x3ea98c = new Folder(_0x4bc8b6[hx_0x222a(0x2a2)]);
            if (_0x3ea98c[hx_0x222a(0x2a8)])
                _0x31e1e0[hx_0x222a(0x1f4)](_0x3ea98c);
        }
        var _0x534e6f = _0x4bc8b6['mediaCache'][hx_0x222a(0x1dd)](hx_0x222a(0x2aa), ''), _0x2fc121 = new Folder(_0x534e6f);
        if (_0x2fc121[hx_0x222a(0x2a8)] && _0x534e6f !== _0x4bc8b6['mediaCache'])
            _0x31e1e0[hx_0x222a(0x1f4)](_0x2fc121);
        if (_0x31e1e0['length'] === 0x0)
            return hx_0x222a(0x2ab);
        var _0x1ddf77 = !![];
        for (var _0x22b532 = 0x0; _0x22b532 < _0x31e1e0[hx_0x222a(0x1f2)]; _0x22b532++) {
            if (!removeFolderContents(_0x31e1e0[_0x22b532]))
                _0x1ddf77 = ![];
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': _0x1ddf77,
            'count': _0x31e1e0[hx_0x222a(0x1f2)]
        });
    } catch (_0x1835e9) {
        return hx_0x222a(0x1f1) + _0x1835e9['toString']();
    }
}
function AeEff_cleanAll() {
    try {
        var _0xb4bf15 = readPrefCachePath(), _0x16a059 = !![], _0x36eedf = !![], _0x4c0ad8 = new Folder(_0xb4bf15['diskCache']);
        if (_0x4c0ad8['exists'])
            _0x16a059 = removeFolderContents(_0x4c0ad8);
        var _0x18c29e = [_0xb4bf15[hx_0x222a(0x29e)]];
        if (_0xb4bf15['peaks'])
            _0x18c29e['push'](_0xb4bf15['peaks']);
        var _0x353ce7 = _0xb4bf15['mediaCache']['replace'](hx_0x222a(0x2aa), '');
        if (_0x353ce7 !== _0xb4bf15['mediaCache']) {
            var _0x1c73aa = new Folder(_0x353ce7);
            if (_0x1c73aa['exists'])
                _0x18c29e['push'](_0x353ce7);
        }
        for (var _0x2599d2 = 0x0; _0x2599d2 < _0x18c29e['length']; _0x2599d2++) {
            var _0x83991d = new Folder(_0x18c29e[_0x2599d2]);
            if (_0x83991d[hx_0x222a(0x2a8)]) {
                if (!removeFolderContents(_0x83991d))
                    _0x36eedf = ![];
            }
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': _0x16a059 && _0x36eedf,
            'disk': _0x16a059,
            'media': _0x36eedf
        });
    } catch (_0xa95274) {
        return 'ERR:' + _0xa95274[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getSelectedProjectItems(_0x1ddc72) {
    try {
        var _0xd61aa7 = [], _0x27cb5b = app[hx_0x222a(0x1f6)]['selection'];
        for (var _0x3b7205 = 0x0; _0x3b7205 < _0x27cb5b[hx_0x222a(0x1f2)]; _0x3b7205++) {
            var _0x4c3da6 = _0x27cb5b[_0x3b7205];
            if (!_0x4c3da6)
                continue;
            if (_0x1ddc72 === hx_0x222a(0x2ac) && _0x4c3da6 instanceof CompItem)
                _0xd61aa7[hx_0x222a(0x1f4)](_0x4c3da6[hx_0x222a(0x1fd)]);
            else {
                if (_0x1ddc72 === hx_0x222a(0x2ad) && _0x4c3da6 instanceof FootageItem)
                    _0xd61aa7['push'](_0x4c3da6[hx_0x222a(0x1fd)]);
                else
                    _0x1ddc72 === hx_0x222a(0x2ae) && _0xd61aa7['push'](_0x4c3da6['name']);
            }
        }
        return JSON[hx_0x222a(0x228)](_0xd61aa7);
    } catch (_0x4ba61a) {
        return 'ERR:' + _0x4ba61a[hx_0x222a(0x1e4)]();
    }
}
function AeEff_batchRename(_0x1f904c, _0xa03178) {
    try {
        var _0x1b0c5f = app[hx_0x222a(0x1f6)][hx_0x222a(0x23a)];
        if (!_0x1b0c5f || _0x1b0c5f['length'] === 0x0)
            return hx_0x222a(0x2af);
        if (!_0x1f904c || _0x1f904c['length'] === 0x0)
            return hx_0x222a(0x2b0);
        if (_0xa03178 === undefined || _0xa03178 === null)
            _0xa03178 = '';
        var _0x2d5610 = 0x0;
        app['beginUndoGroup']('批量重命名');
        for (var _0x47fb33 = 0x0; _0x47fb33 < _0x1b0c5f['length']; _0x47fb33++) {
            var _0x5eb3f9 = _0x1b0c5f[_0x47fb33];
            if (!_0x5eb3f9)
                continue;
            if (typeof _0x5eb3f9['name'] === 'string' && _0x5eb3f9['name']['indexOf'](_0x1f904c) >= 0x0)
                try {
                    _0x5eb3f9[hx_0x222a(0x1fd)] = _0x5eb3f9['name'][hx_0x222a(0x2b1)](_0x1f904c)[hx_0x222a(0x24a)](_0xa03178), _0x2d5610++;
                } catch (_0x56538e) {
                }
        }
        return app['endUndoGroup'](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'total': _0x1b0c5f[hx_0x222a(0x1f2)],
            'renamed': _0x2d5610,
            'find': _0x1f904c,
            'replace': _0xa03178
        });
    } catch (_0x223d85) {
        return hx_0x222a(0x1f1) + _0x223d85['toString']();
    }
}
function AeEff_applyFrameRate(_0x27ea71) {
    try {
        var _0x25e02d = parseFloat(_0x27ea71);
        if (isNaN(_0x25e02d) || _0x25e02d <= 0x0)
            return hx_0x222a(0x2b2);
        var _0x50e999 = app[hx_0x222a(0x1f6)]['selection'];
        if (!_0x50e999 || _0x50e999[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x2af);
        var _0x2c4af1 = _0x50e999[hx_0x222a(0x1f2)], _0x26c16c = 0x0, _0x4e1013 = 0x0, _0x2f4ece = [];
        app[hx_0x222a(0x20e)](hx_0x222a(0x2b3));
        for (var _0x56410c = 0x0; _0x56410c < _0x50e999[hx_0x222a(0x1f2)]; _0x56410c++) {
            var _0xff7b8d = _0x50e999[_0x56410c];
            if (_0xff7b8d instanceof FootageItem && _0xff7b8d[hx_0x222a(0x1f7)]) {
                _0x26c16c++;
                try {
                    _0xff7b8d['mainSource'][hx_0x222a(0x2b4)] = _0x25e02d, _0x4e1013++;
                } catch (_0x4f18e0) {
                    _0x2f4ece['push'](_0xff7b8d[hx_0x222a(0x1fd)] + ':\x20' + _0x4f18e0['toString']());
                }
            }
        }
        return app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'total': _0x2c4af1,
            'fileCount': _0x26c16c,
            'modified': _0x4e1013,
            'fps': _0x25e02d,
            'errors': _0x2f4ece
        });
    } catch (_0x83047e) {
        return hx_0x222a(0x1f1) + _0x83047e[hx_0x222a(0x1e4)]();
    }
}
function AeEff_applyLoopTimes(_0x35d293) {
    try {
        var _0x31e8b9 = parseInt(_0x35d293, 0xa);
        if (isNaN(_0x31e8b9) || _0x31e8b9 < 0x1)
            return 'ERR:invalid_loop';
        var _0x4e9b9a = app['project'][hx_0x222a(0x23a)];
        if (!_0x4e9b9a || _0x4e9b9a[hx_0x222a(0x1f2)] === 0x0)
            return 'ERR:no_selection';
        var _0x44bfbb = _0x4e9b9a['length'], _0x2d8d54 = 0x0, _0xcce628 = 0x0, _0x2ffcf3 = [];
        app[hx_0x222a(0x20e)](hx_0x222a(0x2b5));
        for (var _0x2b90d7 = 0x0; _0x2b90d7 < _0x4e9b9a[hx_0x222a(0x1f2)]; _0x2b90d7++) {
            var _0x2b9ca6 = _0x4e9b9a[_0x2b90d7];
            if (_0x2b9ca6 instanceof FootageItem && _0x2b9ca6[hx_0x222a(0x1f7)]) {
                _0x2d8d54++;
                try {
                    _0x2b9ca6[hx_0x222a(0x2b6)][hx_0x222a(0x2b7)] = _0x31e8b9, _0xcce628++;
                } catch (_0x3dd594) {
                    _0x2ffcf3['push'](_0x2b9ca6[hx_0x222a(0x1fd)] + ':\x20' + _0x3dd594[hx_0x222a(0x1e4)]());
                }
            }
        }
        return app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'total': _0x44bfbb,
            'fileCount': _0x2d8d54,
            'modified': _0xcce628,
            'loop': _0x31e8b9,
            'errors': _0x2ffcf3
        });
    } catch (_0x2ca9dc) {
        return hx_0x222a(0x1f1) + _0x2ca9dc[hx_0x222a(0x1e4)]();
    }
}
var AeEff_GROUP_TAG = hx_0x222a(0x2b8), AeEff_MEMBER_TAG = hx_0x222a(0x2b9);
function AeEff_groupMetaFromComment(_0x5c65d6) {
    if (!_0x5c65d6 || typeof _0x5c65d6 !== 'string')
        return null;
    var _0xfe7a3e = _0x5c65d6[hx_0x222a(0x240)](AeEff_GROUP_TAG);
    if (_0xfe7a3e < 0x0)
        return null;
    var _0x18307b = _0x5c65d6[hx_0x222a(0x2ba)](_0xfe7a3e + AeEff_GROUP_TAG[hx_0x222a(0x1f2)]);
    try {
        return JSON[hx_0x222a(0x1df)](_0x18307b);
    } catch (_0x49a17e) {
        return null;
    }
}
function AeEff_isMemberOf(_0xede1f6, _0x44fb93) {
    try {
        if (!_0xede1f6 || !_0xede1f6[hx_0x222a(0x2bb)])
            return ![];
        return _0xede1f6['comment']['indexOf'](AeEff_MEMBER_TAG + _0x44fb93) >= 0x0;
    } catch (_0x553518) {
        return ![];
    }
}
function AeEff_getGroupMembers(_0xb5deb, _0xdb96c5) {
    var _0x48a178 = [];
    try {
        for (var _0x1047a4 = 0x1; _0x1047a4 <= _0xb5deb[hx_0x222a(0x203)]; _0x1047a4++) {
            if (AeEff_isMemberOf(_0xb5deb['layer'](_0x1047a4), _0xdb96c5))
                _0x48a178[hx_0x222a(0x1f4)](_0xb5deb[hx_0x222a(0x204)](_0x1047a4));
        }
    } catch (_0xe987b4) {
    }
    return _0x48a178;
}
function AeEff_stripMemberTag(_0x21bb05, _0x18f0a2) {
    if (!_0x21bb05)
        return '';
    var _0x37adc8 = AeEff_MEMBER_TAG + _0x18f0a2, _0x3fff8a = '', _0x2f675d = 0x0, _0x352cae;
    while ((_0x352cae = _0x21bb05[hx_0x222a(0x240)](_0x37adc8, _0x2f675d)) >= 0x0) {
        _0x3fff8a += _0x21bb05[hx_0x222a(0x2ba)](_0x2f675d, _0x352cae), _0x2f675d = _0x352cae + _0x37adc8[hx_0x222a(0x1f2)];
    }
    return _0x3fff8a += _0x21bb05[hx_0x222a(0x2ba)](_0x2f675d), _0x3fff8a[hx_0x222a(0x1dd)](/\s+/g, '\x20')[hx_0x222a(0x2bc)]();
}
function AeEff_findGroupHeader(_0x3c9bce) {
    try {
        var _0x311414 = app[hx_0x222a(0x1f6)]['activeItem'];
        if (!_0x311414 || !(_0x311414 instanceof CompItem))
            return null;
        for (var _0x3b486a = 0x1; _0x3b486a <= _0x311414['numLayers']; _0x3b486a++) {
            var _0x5ac078 = _0x311414[hx_0x222a(0x204)](_0x3b486a);
            if (!_0x5ac078[hx_0x222a(0x2bd)])
                continue;
            var _0x3cc399 = AeEff_groupMetaFromComment(_0x5ac078[hx_0x222a(0x2bb)]);
            if (_0x3cc399 && _0x3cc399['id'] === _0x3c9bce)
                return _0x5ac078;
        }
    } catch (_0x1ec5aa) {
    }
    return null;
}
function AeEff_updateGroupMeta(_0x599ba4, _0x5eef7c) {
    var _0x2572c = AeEff_groupMetaFromComment(_0x599ba4[hx_0x222a(0x2bb)]) || {
        'id': '',
        'name': '',
        'color': 0x0,
        'collapsed': ![],
        'solo': ![]
    };
    for (var _0x5b5989 in _0x5eef7c) {
        if (_0x5eef7c['hasOwnProperty'](_0x5b5989))
            _0x2572c[_0x5b5989] = _0x5eef7c[_0x5b5989];
    }
    return _0x599ba4[hx_0x222a(0x2bb)] = AeEff_GROUP_TAG + JSON['stringify'](_0x2572c), _0x2572c;
}
function AeEff_getLayerGroupCompInfo() {
    try {
        var _0x5a7756 = app['project'][hx_0x222a(0x1ea)];
        if (!_0x5a7756 || !(_0x5a7756 instanceof CompItem))
            return JSON['stringify']({
                'ok': !![],
                'hasComp': ![]
            });
        return JSON['stringify']({
            'ok': !![],
            'hasComp': !![],
            'name': _0x5a7756[hx_0x222a(0x1fd)],
            'numLayers': _0x5a7756[hx_0x222a(0x203)],
            'selected': _0x5a7756[hx_0x222a(0x1ec)][hx_0x222a(0x1f2)]
        });
    } catch (_0x36a44d) {
        return 'ERR:' + _0x36a44d[hx_0x222a(0x1e4)]();
    }
}
function AeEff_createLayerGroup(_0xa4ef94) {
    try {
        var _0x5149da = AeEff_parseArg(_0xa4ef94);
        if (typeof _0x5149da !== hx_0x222a(0x2be) || !_0x5149da)
            _0x5149da = '图层组';
        var _0x51b4cb = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x51b4cb || !(_0x51b4cb instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x5c37d8 = _0x51b4cb['selectedLayers'];
        if (!_0x5c37d8 || _0x5c37d8[hx_0x222a(0x1f2)] === 0x0)
            return hx_0x222a(0x2af);
        app[hx_0x222a(0x20e)](hx_0x222a(0x2bf));
        var _0x4510c6 = _0x51b4cb['layers'][hx_0x222a(0x2c0)]();
        _0x4510c6['name'] = _0x5149da;
        var _0xbaf597 = 'g' + new Date()[hx_0x222a(0x2c1)]()[hx_0x222a(0x1e4)](0x24) + Math['floor'](Math[hx_0x222a(0x222)]() * 0x3e8)[hx_0x222a(0x1e4)](0x24), _0x106498 = 0x0;
        for (var _0x562099 = 0x0; _0x562099 < _0x5c37d8['length']; _0x562099++) {
            var _0x1f515c = _0x5c37d8[_0x562099];
            if (_0x1f515c === _0x4510c6)
                continue;
            !AeEff_isMemberOf(_0x1f515c, _0xbaf597) && (_0x1f515c[hx_0x222a(0x2bb)] = (_0x1f515c[hx_0x222a(0x2bb)] ? _0x1f515c['comment'] + '\x20' : '') + AeEff_MEMBER_TAG + _0xbaf597, _0x106498++);
        }
        var _0x1cc9fd = {
            'id': _0xbaf597,
            'name': _0x5149da,
            'collapsed': ![],
            'solo': ![],
            'memberCount': _0x106498
        };
        return _0x4510c6[hx_0x222a(0x2bb)] = AeEff_GROUP_TAG + JSON[hx_0x222a(0x228)](_0x1cc9fd), app['endUndoGroup'](), JSON['stringify']({
            'ok': !![],
            'id': _0xbaf597,
            'name': _0x5149da,
            'memberCount': _0x106498
        });
    } catch (_0x4f1eef) {
        return hx_0x222a(0x1f1) + _0x4f1eef['toString']();
    }
}
function AeEff_addToGroup(_0x3db8a3) {
    try {
        var _0x978225 = AeEff_parseArg(_0x3db8a3);
        if (!_0x978225)
            return hx_0x222a(0x2c2);
        var _0x42cfbe = AeEff_findGroupHeader(_0x978225);
        if (!_0x42cfbe)
            return hx_0x222a(0x2c3);
        var _0x342075 = app[hx_0x222a(0x1f6)]['activeItem'];
        if (!_0x342075 || !(_0x342075 instanceof CompItem))
            return 'ERR:no_comp';
        var _0xff88c7 = _0x342075[hx_0x222a(0x1ec)];
        if (!_0xff88c7 || _0xff88c7[hx_0x222a(0x1f2)] === 0x0)
            return 'ERR:no_selection';
        app['beginUndoGroup']('添加图层到组');
        var _0x50b50d = 0x0, _0x2efbb1 = [], _0x39a90d = AeEff_groupMetaFromComment(_0x42cfbe['comment']) || {}, _0x2b72fa = !!_0x39a90d['collapsed'];
        for (var _0x16ce62 = 0x0; _0x16ce62 < _0xff88c7[hx_0x222a(0x1f2)]; _0x16ce62++) {
            var _0x2b2b53 = _0xff88c7[_0x16ce62];
            if (_0x2b2b53 === _0x42cfbe)
                continue;
            if (!AeEff_isMemberOf(_0x2b2b53, _0x978225)) {
                _0x2b2b53[hx_0x222a(0x2bb)] = (_0x2b2b53[hx_0x222a(0x2bb)] ? _0x2b2b53[hx_0x222a(0x2bb)] + '\x20' : '') + AeEff_MEMBER_TAG + _0x978225;
                try {
                    _0x2b2b53[hx_0x222a(0x2c4)] = _0x2b72fa;
                } catch (_0x3ec7e3) {
                }
                _0x2efbb1['push'](_0x2b2b53), _0x50b50d++;
            }
        }
        if (_0x2b72fa && _0x2efbb1[hx_0x222a(0x1f2)] > 0x0)
            try {
                if (_0x342075['hideShyLayers'] !== !![])
                    _0x342075[hx_0x222a(0x2c5)] = !![];
            } catch (_0x134327) {
            }
        var _0x3d5709 = AeEff_getGroupMembers(_0x342075, _0x978225);
        return AeEff_updateGroupMeta(_0x42cfbe, { 'memberCount': _0x3d5709[hx_0x222a(0x1f2)] }), app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'added': _0x50b50d,
            'memberCount': _0x3d5709[hx_0x222a(0x1f2)]
        });
    } catch (_0x149401) {
        return hx_0x222a(0x1f1) + _0x149401[hx_0x222a(0x1e4)]();
    }
}
function AeEff_listLayerGroups() {
    try {
        var _0x4e7ac8 = app[hx_0x222a(0x1f6)]['activeItem'];
        if (!_0x4e7ac8 || !(_0x4e7ac8 instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x156d84 = [];
        for (var _0x56d5b7 = 0x1; _0x56d5b7 <= _0x4e7ac8[hx_0x222a(0x203)]; _0x56d5b7++) {
            var _0x500cc7 = _0x4e7ac8['layer'](_0x56d5b7);
            if (!_0x500cc7[hx_0x222a(0x2bd)])
                continue;
            var _0x1e1482 = AeEff_groupMetaFromComment(_0x500cc7[hx_0x222a(0x2bb)]);
            if (!_0x1e1482)
                continue;
            var _0x2ae52f = 0x0;
            for (var _0x3afdb1 = 0x1; _0x3afdb1 <= _0x4e7ac8['numLayers']; _0x3afdb1++) {
                if (AeEff_isMemberOf(_0x4e7ac8[hx_0x222a(0x204)](_0x3afdb1), _0x1e1482['id']))
                    _0x2ae52f++;
            }
            _0x156d84[hx_0x222a(0x1f4)]({
                'id': _0x1e1482['id'],
                'name': _0x1e1482[hx_0x222a(0x1fd)],
                'color': _0x1e1482[hx_0x222a(0x2c6)] || 0x0,
                'collapsed': !!_0x1e1482['collapsed'],
                'solo': !!_0x1e1482[hx_0x222a(0x2c7)],
                'memberCount': _0x2ae52f,
                'index': _0x56d5b7
            });
        }
        return JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'groups': _0x156d84
        });
    } catch (_0x73e45) {
        return 'ERR:' + _0x73e45['toString']();
    }
}
function AeEff_toggleGroupCollapse(_0x1ce8c2) {
    try {
        var _0x11a2e6 = AeEff_parseArg(_0x1ce8c2), _0x24b599 = AeEff_findGroupHeader(_0x11a2e6);
        if (!_0x24b599)
            return hx_0x222a(0x2c3);
        var _0x4173fb = app['project'][hx_0x222a(0x1ea)], _0xd77044 = AeEff_groupMetaFromComment(_0x24b599['comment']) || {}, _0x51a73c = !_0xd77044[hx_0x222a(0x2c8)];
        try {
            _0x24b599['shy'] = _0x51a73c;
        } catch (_0x456e37) {
        }
        app[hx_0x222a(0x20e)](hx_0x222a(0x2c9));
        var _0x4b7c4e = AeEff_getGroupMembers(_0x4173fb, _0x11a2e6);
        for (var _0x5a74bd = 0x0; _0x5a74bd < _0x4b7c4e[hx_0x222a(0x1f2)]; _0x5a74bd++) {
            try {
                _0x4b7c4e[_0x5a74bd][hx_0x222a(0x2c4)] = _0x51a73c;
            } catch (_0x590d77) {
            }
        }
        var _0x4e4a0d = _0x51a73c;
        for (var _0x38032c = 0x1; _0x38032c <= _0x4173fb['numLayers']; _0x38032c++) {
            var _0x2719f2 = _0x4173fb['layer'](_0x38032c);
            if (!_0x2719f2['nullLayer'])
                continue;
            var _0x2620c4 = AeEff_groupMetaFromComment(_0x2719f2['comment']);
            if (!_0x2620c4 || _0x2620c4['id'] === _0x11a2e6)
                continue;
            _0x2620c4[hx_0x222a(0x2c8)] && (_0x4e4a0d = !![]);
        }
        try {
            if (_0x4173fb[hx_0x222a(0x2c5)] !== _0x4e4a0d)
                _0x4173fb['hideShyLayers'] = _0x4e4a0d;
        } catch (_0x4c3e74) {
        }
        return AeEff_updateGroupMeta(_0x24b599, { 'collapsed': _0x51a73c }), app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'collapsed': _0x51a73c
        });
    } catch (_0x4ce4a7) {
        return 'ERR:' + _0x4ce4a7[hx_0x222a(0x1e4)]();
    }
}
function AeEff_toggleGroupSolo(_0x5c28fb) {
    try {
        var _0x2f8c2f = AeEff_parseArg(_0x5c28fb), _0x3e0359 = AeEff_findGroupHeader(_0x2f8c2f);
        if (!_0x3e0359)
            return 'ERR:group_not_found';
        var _0x2bf8d1 = app['project'][hx_0x222a(0x1ea)], _0x473d95 = AeEff_groupMetaFromComment(_0x3e0359['comment']) || {}, _0x1cb86a = !_0x473d95[hx_0x222a(0x2c7)], _0x599fe3 = AeEff_getGroupMembers(_0x2bf8d1, _0x2f8c2f);
        app[hx_0x222a(0x20e)](hx_0x222a(0x2ca));
        if (_0x1cb86a) {
            for (var _0x5b845f = 0x1; _0x5b845f <= _0x2bf8d1[hx_0x222a(0x203)]; _0x5b845f++) {
                try {
                    _0x2bf8d1['layer'](_0x5b845f)[hx_0x222a(0x2c7)] = ![];
                } catch (_0x4271b3) {
                }
            }
            for (var _0x2b88d3 = 0x0; _0x2b88d3 < _0x599fe3[hx_0x222a(0x1f2)]; _0x2b88d3++) {
                try {
                    _0x599fe3[_0x2b88d3][hx_0x222a(0x2c7)] = !![];
                } catch (_0x5825f6) {
                }
            }
        } else
            for (var _0x13c941 = 0x0; _0x13c941 < _0x599fe3['length']; _0x13c941++) {
                try {
                    _0x599fe3[_0x13c941]['solo'] = ![];
                } catch (_0x584165) {
                }
            }
        return AeEff_updateGroupMeta(_0x3e0359, { 'solo': _0x1cb86a }), app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'solo': _0x1cb86a
        });
    } catch (_0x1f0324) {
        return 'ERR:' + _0x1f0324[hx_0x222a(0x1e4)]();
    }
}
function AeEff_renameGroup(_0x4ea75b, _0x72e603) {
    try {
        var _0x5a5e4b = AeEff_parseArg(_0x4ea75b), _0x37cdad = AeEff_parseArg(_0x72e603);
        if (typeof _0x37cdad !== hx_0x222a(0x2be) || !_0x37cdad)
            _0x37cdad = '图层组';
        var _0xb57fdf = AeEff_findGroupHeader(_0x5a5e4b);
        if (!_0xb57fdf)
            return hx_0x222a(0x2c3);
        return app['beginUndoGroup']('重命名图层组'), _0xb57fdf[hx_0x222a(0x1fd)] = _0x37cdad, AeEff_updateGroupMeta(_0xb57fdf, { 'name': _0x37cdad }), app[hx_0x222a(0x202)](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'name': _0x37cdad
        });
    } catch (_0x2d92ff) {
        return 'ERR:' + _0x2d92ff[hx_0x222a(0x1e4)]();
    }
}
function AeEff_ungroup(_0xd53598) {
    try {
        var _0x37ce20 = AeEff_parseArg(_0xd53598), _0x5cbb8f = AeEff_findGroupHeader(_0x37ce20);
        if (!_0x5cbb8f)
            return hx_0x222a(0x2c3);
        var _0x2a3778 = app[hx_0x222a(0x1f6)]['activeItem'], _0x4bb344 = AeEff_getGroupMembers(_0x2a3778, _0x37ce20);
        app[hx_0x222a(0x20e)](hx_0x222a(0x2cb));
        for (var _0x3d3a64 = 0x0; _0x3d3a64 < _0x4bb344[hx_0x222a(0x1f2)]; _0x3d3a64++) {
            try {
                _0x4bb344[_0x3d3a64][hx_0x222a(0x2bb)] = AeEff_stripMemberTag(_0x4bb344[_0x3d3a64]['comment'], _0x37ce20);
            } catch (_0x44d9f0) {
            }
        }
        return _0x5cbb8f[hx_0x222a(0x21d)](), app['endUndoGroup'](), JSON[hx_0x222a(0x228)]({
            'ok': !![],
            'removed': _0x4bb344[hx_0x222a(0x1f2)]
        });
    } catch (_0x194a4f) {
        return hx_0x222a(0x1f1) + _0x194a4f['toString']();
    }
}
function AeEff_reorderGroup(_0x54c741, _0x2b73ca, _0x468045) {
    try {
        var _0x3e17f6 = AeEff_parseArg(_0x54c741), _0x44e6b7 = AeEff_parseArg(_0x2b73ca), _0x153713 = AeEff_parseArg(_0x468045) || 'above';
        if (!_0x3e17f6)
            return hx_0x222a(0x2c2);
        var _0x805aa1 = AeEff_findGroupHeader(_0x3e17f6);
        if (!_0x805aa1)
            return 'ERR:group_not_found';
        if (_0x44e6b7 && _0x44e6b7 === _0x3e17f6)
            return JSON[hx_0x222a(0x228)]({
                'ok': !![],
                'moved': ![]
            });
        var _0x4c22f1 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1ea)];
        if (!_0x4c22f1 || !(_0x4c22f1 instanceof CompItem))
            return hx_0x222a(0x1eb);
        var _0x35aa63 = [_0x805aa1][hx_0x222a(0x2cc)](AeEff_getGroupMembers(_0x4c22f1, _0x3e17f6)), _0x1670c8 = [];
        for (var _0x23495f = 0x0; _0x23495f < _0x35aa63['length']; _0x23495f++)
            _0x1670c8['push']({
                'ly': _0x35aa63[_0x23495f],
                'idx': _0x35aa63[_0x23495f]['index']
            });
        _0x1670c8[hx_0x222a(0x234)](function (_0x2f6837, _0x53e96e) {
            return _0x2f6837['idx'] - _0x53e96e['idx'];
        }), app['beginUndoGroup'](hx_0x222a(0x2cd));
        if (_0x153713 === hx_0x222a(0x27e))
            for (var _0x55db2f = _0x1670c8['length'] - 0x1; _0x55db2f >= 0x0; _0x55db2f--) {
                try {
                    _0x1670c8[_0x55db2f]['ly'][hx_0x222a(0x20a)]();
                } catch (_0x1b847a) {
                }
            }
        else {
            if (_0x153713 === hx_0x222a(0x2ce))
                for (var _0x2cc9f6 = 0x0; _0x2cc9f6 < _0x1670c8[hx_0x222a(0x1f2)]; _0x2cc9f6++) {
                    try {
                        _0x1670c8[_0x2cc9f6]['ly'][hx_0x222a(0x2cf)]();
                    } catch (_0x5a8041) {
                    }
                }
            else {
                if (_0x153713 === 'below') {
                    var _0xbdc893 = null, _0xaa66fc = _0x44e6b7 ? AeEff_findGroupHeader(_0x44e6b7) : null;
                    if (_0xaa66fc) {
                        var _0x5ccb14 = AeEff_getGroupMembers(_0x4c22f1, _0x44e6b7), _0x53de67 = _0xaa66fc['index'];
                        for (var _0x215770 = 0x0; _0x215770 < _0x5ccb14[hx_0x222a(0x1f2)]; _0x215770++) {
                            if (_0x5ccb14[_0x215770]['index'] > _0x53de67)
                                _0x53de67 = _0x5ccb14[_0x215770][hx_0x222a(0x280)];
                        }
                        _0xbdc893 = _0x4c22f1['layer'](_0x53de67);
                    }
                    if (!_0xbdc893 || _0xbdc893 === _0x805aa1 || AeEff_isMemberOf(_0xbdc893, _0x3e17f6))
                        for (var _0x1a689c = 0x0; _0x1a689c < _0x1670c8['length']; _0x1a689c++) {
                            try {
                                _0x1670c8[_0x1a689c]['ly'][hx_0x222a(0x2cf)]();
                            } catch (_0x11824a) {
                            }
                        }
                    else
                        for (var _0x374a17 = _0x1670c8[hx_0x222a(0x1f2)] - 0x1; _0x374a17 >= 0x0; _0x374a17--) {
                            if (_0x1670c8[_0x374a17]['ly'] === _0xbdc893)
                                continue;
                            try {
                                _0x1670c8[_0x374a17]['ly']['moveAfter'](_0xbdc893);
                            } catch (_0x442df8) {
                            }
                        }
                } else {
                    var _0x50a4de = _0x44e6b7 ? AeEff_findGroupHeader(_0x44e6b7) : null;
                    if (!_0x50a4de)
                        for (var _0x3421cd = _0x1670c8['length'] - 0x1; _0x3421cd >= 0x0; _0x3421cd--) {
                            try {
                                _0x1670c8[_0x3421cd]['ly']['moveToBeginning']();
                            } catch (_0x4f65d2) {
                            }
                        }
                    else
                        for (var _0x2ef727 = 0x0; _0x2ef727 < _0x1670c8[hx_0x222a(0x1f2)]; _0x2ef727++) {
                            if (_0x1670c8[_0x2ef727]['ly'] === _0x50a4de)
                                continue;
                            try {
                                _0x1670c8[_0x2ef727]['ly']['moveBefore'](_0x50a4de);
                            } catch (_0x4c2563) {
                            }
                        }
                }
            }
        }
        return app['endUndoGroup'](), JSON['stringify']({
            'ok': !![],
            'moved': !![]
        });
    } catch (_0x1136f9) {
        return hx_0x222a(0x1f1) + _0x1136f9[hx_0x222a(0x1e4)]();
    }
}
function AeEff_getProjectFingerprint() {
    try {
        if (!app['project'])
            return hx_0x222a(0x2d0);
        var _0x4c2682 = app[hx_0x222a(0x1f6)][hx_0x222a(0x1f7)] && app['project']['file']['fsName'] ? app['project'][hx_0x222a(0x1f7)][hx_0x222a(0x1f9)] : hx_0x222a(0x2d1), _0x31709f = app['project']['id'] ? app[hx_0x222a(0x1f6)]['id'] : 'NOID';
        return _0x4c2682 + '|' + _0x31709f;
    } catch (_0x51e503) {
        return 'ERR:' + _0x51e503['toString']();
    }
}